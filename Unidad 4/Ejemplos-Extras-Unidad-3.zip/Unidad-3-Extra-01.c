/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 3
	
	
	Par�metros de la funci�n main()
	
*/

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	
	printf("\n Ejecuta \"Extra 01\" \n");
	
	if (argc > 1)
		return 1;
	

return 0;	
}

