/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 3
	
	
	Par�metros de la funci�n main()
	
*/

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	
	char str[20]={};
	
	strcat(str, argv[1]);
	strcat(str, " ");
	strcat(str, argv[2]);
	
	if (system(str) == 1)
		printf("\n %30s", "Clave correcta");
	else
		printf("\n %30s", "Error!!!!!!!! ");
	
printf("\n\n");
return 0;	
}

