/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 3
	
	
	Par�metros de la funci�n main()
	
*/

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	
	if(system("extra01"))
		printf("\n SI");	
	else
		printf("\n NO");
	

return 0;	
}

