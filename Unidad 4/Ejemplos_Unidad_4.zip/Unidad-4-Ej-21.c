/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 21 - Registros en Lenguaje C: Registros anidados definidos con typedef
*/

#include <stdio.h>
#include <string.h>

typedef struct {
	int	dia;
	char	mes[10];
	int 	anio;
	} fecha;
	
typedef struct {
	char	calle[15];
	int	num;
	char	localidad[20];
	}domicilio;

typedef struct {
	char		nombres[18];
	char		apellidos[15];
	fecha		fechaNac;
	domicilio	domic;
	} datos;

int main( int argc, char *argv[])
{
	datos  persona;

	// ...
	// ...
	
printf("\n\n");
return 0;
}


