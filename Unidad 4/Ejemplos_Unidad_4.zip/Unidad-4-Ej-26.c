/*  
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 26 - Registros en Lenguaje C: Puntero a registros
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defReg2.h"

int main( int argc, char *argv[])
{
	struct datos  *ptrStruct;
	struct datos persona;
	
	
	ptrStruct = &persona;
	strcpy(ptrStruct->apellidos , "Maza");
	strcpy(ptrStruct->domic.calle , "Bolivar");
	ptrStruct->domic.num = 215;
	
	printf("\n Apellidos: %s", ptrStruct->apellidos);
	printf("\n Calle: %s", ptrStruct->domic.calle);
	printf("\n Numero: %d", ptrStruct->domic.num);
	
printf("\n\n");
return 0;
}
