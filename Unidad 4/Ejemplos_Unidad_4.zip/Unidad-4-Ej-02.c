/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 2
	Registros en Lenguaje C: Declaraci�n de variables en la definici�n
*/

#include <stdio.h>

int main( int argc, char *argv[])
{
	struct nroCcomplejo {
		float a;
		float b;
	} z1, z2;

	struct parOrdenado {
		float a;
		float b;
	} par1, par2;

		
printf("\n\n");
return 0;
}


