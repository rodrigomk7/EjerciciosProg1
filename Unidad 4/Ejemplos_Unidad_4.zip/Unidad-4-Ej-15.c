/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 15 - Registros en Lenguaje C: Paso de registros por valor
*/

#include <stdio.h>
#include "registros.h"

void structPorValor1(struct nroComplejo);
void structPorValor2(coordenadas1 );

int main( int argc, char *argv[])
{
	struct nroComplejo 	z = {1.1, 2.2};
	coordenadas1 		punto1 = {3.3, 4};
	
	printf("\n Paso de registros por valor");
	printf("\n ===========================\n");
	printf("\n %-45s ","Complejo antes de la llamada: ");
	printf(" %5.2f + %5.2f i", z.a, z.b);
	structPorValor1(z);
	printf("\n %-45s ","Complejo despues de la llamada: ");
	printf(" %5.2f + %5.2f i", z.a, z.b);
	
	printf("\n\n %-45s ","Punto antes de la llamada:");
	printf(" ( %5.2f , %3d )", punto1.x, punto1.y);
	structPorValor2(punto1);
	printf("\n %-45s ","Punto despues de la llamada:");
	printf(" ( %5.2f , %3d )", punto1.x, punto1.y);
	
printf("\n\n");
return 0;
}

void structPorValor1(struct nroComplejo c)
{	
	printf("\n %-45s  %5.2f + %5.2f i", "Complejo recibido: ", c.a, c.b);
	c.a = .554;
	c.b = .777;
	printf("\n %-45s  %5.2f + %5.2f i", "Complejo modificado: ", c.a, c.b);
	
return;
}

void structPorValor2(coordenadas1 p)
{	
	printf("\n %-45s ","Punto recibido: ");
	printf(" ( %5.2f , %3d )", p.x, p.y);
	p.x = 2.22;
	p.y = 99;
	printf("\n %-45s ","Punto modificado: ");
	printf(" ( %5.2f , %3d )", p.x, p.y);
	
return;
}
