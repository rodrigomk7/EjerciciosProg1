/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 18 - Registros en Lenguaje C: Ejemplo
*/

#include <stdio.h>
#include <string.h>

typedef struct 
{
	char nombres[18];
	char apellidos[15];
	char fechaNac[20];
	char domic[20];
} datos;

int main( int argc, char *argv[])
{
	datos	persona;
	strcpy(persona.nombres, "Elena Isabel");
	strcpy(persona.apellidos, "Maza");
	strcpy(persona.fechaNac , "12 de mayo de 1996");
	
	printf("Ingresar domicilio: ");
	fgets(persona.domic, 18, stdin);
	persona.domic[strlen(persona.domic)-1] = '\0';
		
	printf("\n Apellidos y nombres: %s", persona.apellidos);
	printf(", %s", persona.nombres);
	printf("\n\n Fecha de nacimiento: ");
	printf("%s", persona.fechaNac);
	
	printf("\n\n Domicilio: ");
	printf("%s", persona.domic);
	
printf("\n\n");
return 0;
}


