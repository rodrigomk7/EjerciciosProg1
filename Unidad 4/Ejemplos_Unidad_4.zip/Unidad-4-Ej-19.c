/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 19 - Registros en Lenguaje C: Registros anidados
*/

#include <stdio.h>
#include <string.h>

typedef struct {
	char		nombres[18];
	char		apellidos[15];
	
	struct fecha {
		int	  dia;
		char	  mes[10];
		int 	  anio;
		} fechaNac;
	
	struct domicilio {
		char	  calle[15];
		int	  num;
		char	  localidad[20];
		} domic;
	} datos;


int main(int argc, char *argv[])
{
	datos persona;
	struct fecha hoy = {12 , "mayo" , 2016};
	
	persona.fechaNac.dia = 12;
	strcpy(persona.domic.localidad, "Trancas");
	
	printf("\n Dia nacimiento: %d", persona.fechaNac.dia);
	printf("\n Localidad : %s", persona.domic.localidad);
	printf("\n Hoy: %d  de %s de %d", hoy.dia , hoy.mes , hoy.anio);
	
printf("\n\n");
return 0;
}
