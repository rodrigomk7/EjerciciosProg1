/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 24 - Registros en Lenguaje C: Arreglos de registros
*/

#include <stdio.h>
#include <string.h>

#include "defReg2.h"
#include "funcReg.h"

int main( int argc, char *argv[])
{
	struct datos  lista[10];

	lista[1] = leerRegistro();
	mostrarRegistro(lista[1]);
	
printf("\n\n");
return 0;
}


