/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 25 - Registros en Lenguaje C: Arreglos de registros con altas, bajas y modificaciones
*/
 
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "defReg2.h"
#include "funcReg.h"

int main( int argc, char *argv[])
{
	struct datos  lista[20];
	

	printf("\n %d\n\n", sizeof(lista));
	menu(lista);
	
	
printf("\n");
return 0;
}


