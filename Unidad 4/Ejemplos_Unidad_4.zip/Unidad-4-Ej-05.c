/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 5
	Registros en Lenguaje C: Asignaci�n de valores
*/

#include <stdio.h>

int main( int argc, char *argv[])
{
	struct nroComplejo {
		float a;
		float b;
	};

	struct parOrdenado {
		float a;
		float b;
	};

	typedef struct {
		float 	x;
		int  	y;
	}coordenadas1;
	
	typedef struct {
		float 	x;
		int  	y;
	}coordenadas2;
	
	struct nroComplejo	z1, z2;
	struct parOrdenado	par1, par2;
	
	coordenadas1		punto1 , punto2;
	coordenadas2		puntoB , puntoA;
	
	z1.a  = 55.66;
	z1.b  = 77.88;

	punto1.x  =  -9.01;
	punto1.y  =  -2;
	puntoB.x =  2.345;
	puntoB.y =  -6;
	
printf("\n\n");
return 0;
}
