/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 17 - Registros en Lenguaje C: Operaciones con n�meros complejos
*/

#include <stdio.h>
#include <math.h>
#include "registros.h"

struct nroComplejo leeComplejo();
struct nroComplejo sumaComplejos(struct nroComplejo, struct nroComplejo);
struct nroComplejo restaComplejos(struct nroComplejo, struct nroComplejo);
struct nroComplejo multipComplejos(struct nroComplejo, struct nroComplejo);
struct nroComplejo divideComplejos(struct nroComplejo, struct nroComplejo);

int main( int argc, char *argv[])
{
	struct nroComplejo	z1, z2, z;
			
	printf("\n       INGRESAR COMPLEJO 1");
	z1 = leeComplejo();
	printf("\n       INGRESAR COMPLEJO 2");
	z2 = leeComplejo();
	
	z = sumaComplejos(z1, z2);
	printf("\n %-50s", "La suma de los numeros ingresados es :");
	printf("   %5.2f + %5.2f i", z.a, z.b);
	z = restaComplejos(z1, z2);
	printf("\n %-50s", "La resta de los numeros ingresados es :");
	printf("   %5.2f + %5.2f i", z.a, z.b);
	z = multipComplejos(z1, z2);
	printf("\n %-50s", "La multiplicacion de los numeros ingresados es :");
	printf("   %5.2f + %5.2f i", z.a, z.b);
	z = divideComplejos(z1, z2);
	printf("\n %-50s", "La division de los numeros ingresados es :");
	printf("   %5.2f + %5.2f i", z.a, z.b);
		
printf("\n\n");
return 0;
}

struct nroComplejo leeComplejo()
{
	
	struct nroComplejo z;
	
	printf("\n %-30s", "Ingresar parte real : ");
	scanf("%f", &z.a);
	printf(" %-30s", "Ingresar parte imaginaria : ");
	scanf("%f", &z.b);
return z;	
}

struct nroComplejo sumaComplejos(struct nroComplejo z1, struct nroComplejo z2)
{
	struct nroComplejo c;
	
	c.a = z1.a + z2.a;
	c.b = z1.b + z2.b;
	
return c;	
}

struct nroComplejo restaComplejos(struct nroComplejo z1, struct nroComplejo z2)
{
	struct nroComplejo c;
	
	c.a = z1.a - z2.a;
	c.b = z1.b - z2.b;
	
return c;	
}

struct nroComplejo multipComplejos(struct nroComplejo z1, struct nroComplejo z2)
{
	struct nroComplejo c;
	
	c.a = (z1.a * z2.a) - (z1.b * z2.b);
	c.b = (z1.a * z2.b) + (z1.b * z2.a);	
	
return c;	
}

struct nroComplejo divideComplejos(struct nroComplejo z1, struct nroComplejo z2)
{
	struct nroComplejo c;
	
	c.a = ((z1.a * z2.a) + (z1.b * z2.b))/ ((z2.a * z2.a) + (z2.b * z2.b));
	c.b = ((z1.b * z2.a) - (z1.a * z2.b))/((z2.a * z2.a) + (z2.b * z2.b));
	
return c;	
}
