/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 10
	Registros en Lenguaje C: Definici�n global de registros
*/

#include <stdio.h>
#include <math.h>

struct nroComplejo {
		float a;
		float b;
	};

	typedef struct {
		float 	x;
		int  	y;
	}coordenadas1;

struct nroComplejo leeComplejo();
coordenadas1 leeCoordenadas();
	
int main( int argc, char *argv[])
{
	struct nroComplejo		z1;
	coordenadas1		punto1, punto2;
	float 			aux1 , aux2 , distancia;
	
	punto2.x = 4;
	punto2.y = 6;
	
	z1 = leeComplejo();
	punto1 = leeCoordenadas();
	
	printf(" Complejo: ( %f + %f i)", z1.a, z1.b);
	
	distancia = sqrt(pow( (punto2.x - punto1.x),2)+pow( (punto2.y - punto1.y),2));
	printf("\n\n La distancia entre los puntos 1 y 2 es: %f", distancia);
	
printf("\n\n");
return 0;
}

struct nroComplejo leeComplejo()
{
	struct nroComplejo comp;
	
	comp.a = 5.5;
	comp.b = 7.7;
	
return comp;	
}

coordenadas1 leeCoordenadas()
{
	coordenadas1 c;
	
	c.x = 1;
	c.y = 2;
	
return c;	
}
