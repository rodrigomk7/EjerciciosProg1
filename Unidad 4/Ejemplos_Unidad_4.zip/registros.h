/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Archivo de cabecera con la declaraci�n de registros
*/

struct nroComplejo {
		float a;
		float b;
	};

struct parOrdenado {
		float a;
		float b;
	};

typedef struct {
		float 	x;
		int  	y;
	}coordenadas1;
	
typedef struct {
		float 	x;
		int  	y;
	}coordenadas2;
	
		
		
