/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 3
	Registros en Lenguaje C: Declaraci�n de variables luego de la definici�n
*/

#include <stdio.h>

int main( int argc, char *argv[])
{
	struct nroComplejo {
		float a;
		float b;
	};

	struct parOrdenado {
		float a;
		float b;
	};

	typedef struct {
		float 	x;
		int  	y;
	}coordenadas1;
	
	typedef struct {
		float 	x;
		int  	y;
	}coordenadas2;
	
	struct nroComplejo		z1, z2;
	struct parOrdenado	par1, par2;
	
	coordenadas1		punto1, punto2;
	coordenadas2		puntoA, puntoB;
	
printf("\n\n");
return 0;
}


