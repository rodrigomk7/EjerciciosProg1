/*  
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 30
	Registros en Lenguaje C: Arreglos como atributos de registros con punteros 
			         a registros
*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

struct listaAsign
{
	char nombre[20];
	char asignatura[30][20];
	int nota[30];
};

int main( int argc, char *argv[])
{
	struct listaAsign *lista;
	int n = 2;
	int nroAlumno, nroAsig;
	
	lista = (struct listaAsign*) malloc(n * sizeof(struct listaAsign));
	for ( nroAlumno = 0; nroAlumno < n ; nroAlumno++)
	{
		printf("\n Alumno %d ", nroAlumno+1);
		printf("\t\t Ingrese nombre del alumno: ");
		scanf("%s", (lista+nroAlumno)->nombre);
		printf("\n\n");
		for (nroAsig = 0 ; nroAsig < 2; nroAsig++)
		{
			printf("\tIngrese nombre asignatura: ");
			scanf("%s", (lista+nroAlumno)->asignatura[nroAsig]);
			printf("\tIngrese nota: ");
			scanf("%d", &((lista+nroAlumno)->nota[nroAsig]));
			fgetc(stdin);
		}
	}
	
	for ( nroAlumno = 0; nroAlumno < n ; nroAlumno++)
	{
		printf("\n Alumno %d : %s", nroAlumno+1, (lista+nroAlumno)->nombre);
		for (nroAsig = 0 ; nroAsig < 2; nroAsig++)
		{
			printf("\n\t\t\t %s", (lista+nroAlumno)->asignatura[nroAsig]);
			printf("\t %d",(lista+nroAlumno)->nota[nroAsig]);
		}
	}
	
	free(lista);
printf("\n\n");
return 0;
}
