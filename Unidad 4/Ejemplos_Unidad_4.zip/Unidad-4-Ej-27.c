/*  
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 27 -Registros en Lenguaje C: Puntero a registro con asignaci�n din�mica de memoria
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "defReg2.h"

int main( int argc, char *argv[])
{
	struct datos  *ptrStruct;
	
	ptrStruct = ( struct datos* ) malloc( sizeof( struct datos) );
	
	strcpy(ptrStruct->apellidos , "Maza");
	strcpy(ptrStruct->domic.calle , "Bolivar");
	ptrStruct->domic.num = 225;
	
	printf("\n Apellidos: %s", ptrStruct->apellidos);
	printf("\n Calle: %s", ptrStruct->domic.calle);
	printf("\n Numero: %d", ptrStruct->domic.num);
	
	free(ptrStruct);
	
printf("\n\n");
return 0;
}
