/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	          
	Ejemplo 6
	Registros en Lenguaje C: Asignaci�n de valores a los atributos de un registro utilizando 
			         funciones de entrada de datos
*/

#include <stdio.h>

int main( int argc, char *argv[])
{
	struct nroComplejo {
		float a;
		float b;
	};

	struct parOrdenado {
		float a;
		float b;
	};

	typedef struct {
		float 	x;
		int  	y;
	}coordenadas1;
	
	typedef struct {
		float 	x;
		int  	y;
	}coordenadas2;
	
	struct nroComplejo		z1, z2;
	struct parOrdenado	par1, par2;
	
	coordenadas1		punto1 , punto2;
	coordenadas2		puntoB , puntoA;
	
	printf("\n Ingrese la parte real del complejo: ");
	scanf("%f", &z1.a);
	printf("\n Ingrese la parte imaginaria del complejo: ");
	fscanf(stdin, "%f", &z1.b);
	
	printf("\n Ingrese la coordenada X (float) del punto: ");
	fscanf(stdin, "%f", &punto1.x);
	printf("\n Ingrese la coordenada Y (int) del punto: ");
	fscanf(stdin, "%d", &punto1.y);

printf("\n\n");
return 0;
}
