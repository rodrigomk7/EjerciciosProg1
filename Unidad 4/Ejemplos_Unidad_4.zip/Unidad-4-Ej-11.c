/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 11
	Registros en Lenguaje C: Definici�n de registros en un archivo cabecera
*/

#include <stdio.h>
#include <math.h>
#include "registros.h"

int main( int argc, char *argv[])
{
	struct nroComplejo		z1;
	coordenadas1		punto1, punto2;
	float 			modulo, distancia, fi;
	
	punto1.x = 1;
	punto1.y = 2;
	punto2.x = 4;
	punto2.y = 6;
	
	printf("\n Ingresar parte real del complejo: ");
	scanf("%f", &z1.a);
	printf(" Ingresar parte imaginaria del complejo: ");
	scanf("%f", &z1.b);
	printf(" Complejo: ( %f + %f i)", z1.a, z1.b);
	modulo = sqrt(pow(z1.a,2)+pow(z1.b,2));
	fi = atan(z1.b/z1.a);
	printf("\n El modulo del numero complejo es: %5.2f", modulo);
	printf("\n El argumento fi es de: %5.2f radianes", fi);
	printf("\n El argumento fi es de: %5.2f grados sexagesimales", fi*180/3.1416);
	printf("\n\n\n Punto 1: (%f , %d)", punto1.x , punto1.y);
	printf("       Punto 2: (%f , %d)", punto2.x , punto2.y);
	distancia = sqrt(pow( (punto2.x - punto1.x),2)+pow( (punto2.y - punto1.y),2));
	distancia = pow((pow( (punto2.x - punto1.x),2)+pow( (punto2.y - punto1.y),2)),1.0/2.0);
	printf("\n La distancia entre los puntos 1 y 2 es: %f", distancia);
	
printf("\n\n");
return 0;
}

