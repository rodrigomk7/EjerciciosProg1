/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 16 - Registros en Lenguaje C: Paso de registros por referencia
*/

#include <stdio.h>
#include "registros.h"

void structPorRef1(struct nroComplejo *);
void structPorRef2(coordenadas1 *);

int main( int argc, char *argv[])
{
	struct nroComplejo 	comp = {1.1, 2.2};
	coordenadas1 		punto1 = {3.3, 4.4};
	
	printf("\n Paso de registros por referencia");
	printf("\n ================================\n");
	printf("\n %-45s", "Complejo antes de la llamada: ");
	printf("  %5.2f + %5.2f i",  comp.a, comp.b);
	structPorRef1(&comp);
	printf("\n %-45s", "Complejo despues de la llamada: ");
	printf("  %5.2f + %5.2f i",  comp.a, comp.b);
	printf("\n\n %-45s", "Punto antes de la llamada: ");
	printf(" (%5.2f , %3d) ", punto1.x, punto1.y);
	structPorRef2(&punto1);
	printf("\n %-45s" , "Punto despues de la llamada:  ");
	printf(" (%5.2f , %3d) ", punto1.x, punto1.y);
	
printf("\n\n");
return 0;
}

void structPorRef1(struct nroComplejo *z)
{
	printf("\n %-45s  %5.2f + %5.2f i", "Complejo recibido: ", z->a, z->b);
	z->a = 5.55;
	z->b = 7.77;
	printf("\n %-45s  %5.2f + %5.2f i", "Complejo modificado: ", z->a, z->b);
	
return;
}

void structPorRef2(coordenadas1 *p)
{
	printf("\n %-45s (%5.2f , %3d)", "Punto recibido: ",  p->x, p->y);
	p->x = 1.11;
	p->y = 88;
	printf("\n %-45s (%5.2f , %3d)", "Punto modificado: ", p->x, p->y);

return;
}
