/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 22 - Registros en Lenguaje C: Registros anidados definidos con typedef
*/

#include <stdio.h>
#include <string.h>

typedef struct {
	int	dia;
	char	mes[10];
	int 	anio;
	} fecha;
	
typedef struct {
	char	calle[15];
	int	num;
	char	localidad[20];
	}domicilio;

typedef struct {
	char		nombres[18];
	char		apellidos[15];
	fecha	fechaNac;
	domicilio	domic;
	} datos;

int main( int argc, char *argv[])
{
	datos  persona;

	strcpy(persona.nombres, "Elena Isabel");
	strcpy(persona.apellidos, "Maza");
	
	persona.fechaNac.dia = 12;
	strcpy(persona.fechaNac.mes, "mayo");
	persona.fechaNac.anio = 1996;
	
	strcpy(persona.domic.calle, "Bolivar"); 
	persona.domic.num = 215;
	strcpy(persona.domic.localidad, "Trancas");
	printf("\n%25s %s", "Apellidos y nombres: ", persona.apellidos);
	printf(", %s", persona.nombres);
	printf("\n\n%25s", "Fecha de nacimiento ");
	printf("\n%25s", "=================== ");
	printf("\n%25s %-4d", "Dia: ", persona.fechaNac.dia);
	printf("\n%25s %-15s", "Mes: ", persona.fechaNac.mes);
	printf("\n%25s %-d", "Anio: ", persona.fechaNac.anio);
	printf("\n\n%25s", "Domicilio ");
	printf("\n%25s", "========= ");
	printf("\n%25s %-15s", "Calle: ", persona.domic.calle);
	printf("\n%25s %-4d", "Numero: ", persona.domic.num);
	printf("\n%25s %-15s", "Localidad: ", persona.domic.localidad);
printf("\n\n");
return 0;
}


