/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 8
	Registros en Lenguaje C: Operaciones con los valores de los atributos
*/

#include <stdio.h>

int main( int argc, char *argv[])
{
	struct nroComplejo {
		float a;
		float b;
	};

	struct parOrdenado {
		float a;
		float b;
	};

	typedef struct {
		float 	x;
		int  	y;
	}coordenadas1;
	
	typedef struct {
		float 	x;
		int  	y;
	}coordenadas2;
	
	struct nroComplejo	z1, z2;
	struct parOrdenado	par1, par2;
	
	coordenadas1		punto1 , punto2;
	coordenadas2		puntoB , puntoA;
	
	z1.a  = 55.66 ,  z1.b  = 77.88;   
	puntoB.x =  2.345 , puntoB.y =  -6;   

	z2.a = z1.a;
	z2.b = z1.b;	
	puntoA.x = 2 * puntoB.x; 
	puntoA.y = puntoB.y / 3;

	printf("\n Complejo z1: %f + %f i", z1.a, z1.b);
	printf("\n Complejo z2: %f + %f i", z2.a, z2.b);
	
	printf("\n\n Punto B: ( %f , %d)", puntoB.x, puntoB.y);
	printf("\n Punto A: ( %f , %d)", puntoA.x, puntoA.y);
	
printf("\n\n");
return 0;
}
