/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 9 
	Registros en Lenguaje C: Copia de registros
*/

#include <stdio.h>

int main( int argc, char *argv[])
{
	struct nroComplejo {
		float a;
		float b;
	};

	struct parOrdenado {
		float a;
		float b;
	};

	typedef struct {
		float 	x;
		int  	y;
	}coordenadas1;
	
	typedef struct {
		float 	x;
		int  	y;
	}coordenadas2;
	
	struct nroComplejo		z1, z2;
	struct parOrdenado	par1, par2;
	
	coordenadas1		punto1, punto2;
	coordenadas2		puntoA;
	
	punto1.x =  22.44;
	punto1.y =  -56;
	
	punto2 = punto1;
//	puntoA = punto1;
	puntoA.x = punto1.x;
	
printf("\n\n");
return 0;
}
