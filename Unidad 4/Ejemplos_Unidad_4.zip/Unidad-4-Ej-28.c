/*  
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 28 -Registros en Lenguaje C: Arreglo de registros tratado con asignaci�n 
		din�mica de memoria
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "defReg2.h"
#include "funcReg.h"

int main( int argc, char *argv[])
{
	struct datos  	*ptrStruct;
	int 		n = 2;
	int		cant;
	
	
	
	ptrStruct = ( struct datos* ) malloc( n * sizeof( struct datos) );
	
	*ptrStruct = leerRegistro();
	*(ptrStruct+1) = leerRegistro();
	
	printf("\n\n -----------------------");
	mostrarRegistro(*ptrStruct);
	printf("\n");
	mostrarRegistro(*(ptrStruct+1));
	
	free(ptrStruct);
	
printf("\n\n");
return 0;
}
