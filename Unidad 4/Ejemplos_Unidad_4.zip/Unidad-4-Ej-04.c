/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 4
	Registros en Lenguaje C: Asignaci�n de valores en la declaraci�n de variables
*/

#include <stdio.h>

int main( int argc, char *argv[])
{
	struct nroComplejo {
		float a;
		float b;
	};

	struct parOrdenado {
		float a;
		float b;
	};

	typedef struct {
		float 	x;
		int  	y;
	}coordenadas1;
	
	typedef struct {
		float 	x;
		int  	y;
	}coordenadas2;
	
	struct nroComplejo	z1 = {11.22, 33.44}, z2;
	struct parOrdenado	par1, par2 = {11.33, -22.44};
	
	coordenadas1		punto1 = {3.14, 5}, punto2 = {0.707, -3};
	coordenadas2		puntoB = {8.88, 49}, puntoA;	
	
printf("\n\n");
return 0;
}

