/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 12
	Registros en Lenguaje C: Funciones que devuelven registros
*/

#include <stdio.h>
#include <math.h>
#include "registros.h"

struct nroComplejo leeComplejo();
coordenadas1 leeCoordenadas();

int main( int argc, char *argv[])
{
	struct nroComplejo		z1;
	coordenadas1		punto1;
		
	z1 = leeComplejo();
	printf("\n Complejo:  %f + %f i", z1.a, z1.b);
	punto1 = leeCoordenadas();
	printf("\n El punto es: ( %f , %d)", punto1.x, punto1.y);
	
printf("\n\n");
return 0;
}

struct nroComplejo leeComplejo()
{
	
	struct nroComplejo z;
	
	printf("\n Ingresar parte real del complejo: ");
	scanf("%f", &z.a);
	printf(" Ingresar parte imaginaria del complejo: ");
	scanf("%f", &z.b);
return z;	
}

coordenadas1 leeCoordenadas()
{
	coordenadas1 p;
	printf("\n\n Ingresar el valor de x (real): ");
	scanf("%f", &p.x);
	printf(" Ingresar el valor de y (entero): ");
	scanf("%d", &p.y);
return p;
}
