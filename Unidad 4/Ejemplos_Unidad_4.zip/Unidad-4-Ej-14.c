/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 14 - Registros en Lenguaje C: Paso de par�metros - Atributos por referencia
*/

#include <stdio.h>
#include "registros.h"

void atributosPorReferencia(float *, int *);

int main( int argc, char *argv[])
{
	coordenadas1 	punto1;
	
	punto1.x = 12.34;
	punto1.y = 33;
	
	
	printf("\n Parametros por referencia: ");
	printf("\n ********************* ");
	printf("\n %50s", "Valor de los atributos antes de la llamada: ");
	printf(" %5.2f %6d", punto1.x, punto1.y);
	atributosPorReferencia(&punto1.x,&punto1.y);
	printf("\n %50s", "Valor de los atributos despues de la llamada: ");
	printf(" %5.2f %6d", punto1.x, punto1.y);
	
printf("\n\n");
return 0;
}

void atributosPorReferencia(float *a, int *b)
{
	printf("\n %50s %5.2f %6d ", "Valor que reciben parametros: ", *a, *b);
	*a = 56.78;
	*b = 55;
	printf("\n %50s %5.2f %6d", "Valor modificado de parametros: ", *a, *b);
return;
}

