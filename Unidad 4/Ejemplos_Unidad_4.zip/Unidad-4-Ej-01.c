/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 4
	
	Ejemplo 1
	Registros en Lenguaje C: Definici�n de tipo de datos
*/

#include <stdio.h>

int main( int argc, char *argv[])
{
	struct nroComplejo {
		float a;
		float b;
	};

	struct parOrdenado {
		float a;
		float b;
	};

	typedef struct {
		float 	x;
		int  	y;
	}coordenadas1;
	
	typedef struct {
		float 	x;
		int  	y;
	}coordenadas2;

printf("\n\n");
return 0;
}


