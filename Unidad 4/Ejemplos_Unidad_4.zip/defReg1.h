typedef struct
{
	char nombres[18];
	char apellidos[15];
	char fechaNac[20];
	char domic[20];
} datos;

