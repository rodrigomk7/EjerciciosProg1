/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 5 - Archivos en C
	Escritura en archivos de texto
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	
	FILE 	*ptrFile;
	char 	nombre[ ] = "c:\\prog1\\Ej_5_1.txt";

	// Ver en Linux **********************
	
	ptrFile = fopen( nombre, "r");
	printf("\n  %p", ptrFile);
	fprintf(ptrFile, "\n %c %c %c %c ", 'A', 'B', 'C', 'D');
	fclose(ptrFile);
	
	ptrFile = fopen( nombre, "r+"); 
	printf("\n  %p", ptrFile);
	fprintf(ptrFile, "\n %c %c %c %c", 'e', 'f', 'g', 'h');
	fprintf(ptrFile, "\n %c %c %c %c", 'i', 'm', 'x', 'y');
	fclose(ptrFile);
	
	
	ptrFile = fopen( nombre, "a");
	printf("\n  %p", ptrFile);
	fprintf(ptrFile, "\n %s", " Jueves 28");// %c %c %c ", 'I', 'J', 'K', 'L');
	fclose(ptrFile);
	
	
printf("\n\n");	
return 0;	
}
