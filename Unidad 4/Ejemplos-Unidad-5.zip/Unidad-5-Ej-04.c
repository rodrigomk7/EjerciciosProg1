/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 4 - Archivos en C
	Cierre de archivos
*/

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	
	FILE 	*ptrFile;
	FILE 	*pf;
	//char 	nombre[ ] = "c:\\prog1\\Ej_4_1.txt";

	ptrFile = fopen( "c:\\prog1\\Ej_4_1.txt", "r");
	printf("\n\n Apertura de archivo modo r %p", ptrFile);
	printf("\n Cierre de archivo: %d", fclose(ptrFile));
	
	ptrFile = fopen("c:\\prog1\\Ej_4_1.txt", "w");
	printf("\n\n Apertura de archivo modo w %p", ptrFile);
	printf("\n Cierre de archivo: %d", fclose(ptrFile));
	
	pf = fopen("c:\\prog1\\prueba.txt", "w");
	printf("\n\n Apertura nuevo archivo: %p", pf);
	printf("\n Cierre de archivo abierto: %d", fclose(pf));
	
printf("\n\n");	
return 0;	
}
