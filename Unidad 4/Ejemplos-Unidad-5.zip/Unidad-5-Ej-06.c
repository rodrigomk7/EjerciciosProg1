/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 6 - Archivos en C
	Escritura en archivos de texto
*/

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	
	FILE 	*ptr;
	char 	nombre[ ] = "c:\\prog1\\Ej_5_1.txt";

	
	ptr = fopen( nombre, "a+");
	printf("\n  %p", ptr);
	fprintf(ptr, "%c %c %c %c ", 'Q', 'R', 'S', 'T');
	fputs("\n\nHola\n\t", ptr);
	fputc('u', ptr);
	fputc(' ', ptr);
	fputc('v', ptr);
	fputc('\n', ptr);
	fputc('w', ptr);
	fputc(' ', ptr);
	fputc('x', ptr);
	
	fclose(ptr);
	
printf("\n\n");	
return 0;	
}
