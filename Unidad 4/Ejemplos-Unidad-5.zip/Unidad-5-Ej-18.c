/*  
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 18 - Archivos en C
	Escritura y Lectura en archivos de texto. 
	Uso de registros y men�.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

/*tipos definidos por el usuario*/
typedef struct {
	char apellido[50];
	char nombre[50];
	char cx[8]; 
	int edad;
} alumno;

/*funciones*/
FILE* abrir(char*, char*);
int menu();
int existeArchivo(char *);
alumno obtenerAlumno(char []);
void muestraAlumno(alumno );
void mostrarAlumno(char *);
void primeraAMayusculas(char *);
int validarCX(char []);
alumno leerAlumno();
void guardarAlumno(alumno , char *);


int main(int argc, char *argv[])
{
	FILE 	*pArchivo;
	char 	archivo[50] = "c:\\prog1\\";
	alumno 	alum;
	int 	opcion;

	if (argc < 2)
	{
		printf("Debe ingresar el nombre del archivo");
		return 0;
	}
	else
	{
		strcat(archivo, argv[1]);
		if (existeArchivo(archivo) == 0)
		{
			printf("Error al acceder al archivo %s\n", archivo);
			return 0;
		}
		else
		{ 
			do
			{
				opcion = menu();
				switch(opcion)
				{
					case 1 : alum = leerAlumno();
						guardarAlumno(alum, archivo);
						break;
					case 2 : mostrarAlumno(archivo);
						break;
				}
			}while (opcion > 0 && opcion < 3);	    
		}
	}	
return 0;
}

FILE* abrir(char* n, char* m)
{
	return fopen(n, m);
}
 
int menu()
{
	int opcion = -1;
    
	do
	{
		printf("1. Ingresar alumno\n");
		printf("2. Mostrar alumnos\n");
		printf("0. Salir\n\n");
		printf("Ingrese una opcion: ");
		scanf("%d", &opcion);
	}while (opcion < 0 || opcion > 2);
return opcion;
}

int existeArchivo(char *nombreArchivo)
{
	FILE 	*p;
	int 	resultado;
    
	if ((p = fopen(nombreArchivo, "r")) == NULL)
	{
		if ((p = fopen(nombreArchivo, "w")) == NULL)
			resultado = 0;
		else
		{
			resultado = 1;
			fclose(p);
		}
	}
	else
	{
		resultado = 1;
		fclose(p);
	}
 return resultado;
}

void mostrarAlumno(char *archivo)
{
	FILE 	*pArch;
	char 	cadena[100];
        	alumno 	alum;
        	
        	pArch = abrir(archivo, "r+");
        	while (!feof(pArch))
        	{
        		fscanf(pArch, "%s", cadena);
        		if (feof(pArch))
			break;
    	    
		alum = obtenerAlumno(cadena);
		muestraAlumno(alum);
		getchar(); 
		}
  fclose(pArch);
}

void muestraAlumno(alumno alum)
{
	printf("\n \nApellido: %s\n", alum.apellido);    
	printf("Nombre: %s\n", alum.nombre);    
	printf("CX: %s\n", alum.cx);    
	printf("Edad: %2d\n", alum.edad);
}

alumno leerAlumno()
{
	alumno alum;
	int cxValido;
    
	fgetc(stdin);   
	printf("Ingrese el apellido: ");
	scanf("%s",alum.apellido);
    	primeraAMayusculas(alum.apellido);
	
    	fgetc(stdin); 
    
	printf("Ingrese el nombre: ");    
	scanf("%s", alum.nombre);
	primeraAMayusculas(alum.nombre);
   
	do
	{
		printf("Ingrese el CX del alumno (solo numeros, 7 en total): ");    
		scanf("%s", alum.cx);
	} while (validarCX(alum.cx) != 1);
	alum.cx[7] = '\0';
        
	printf("Ingrese la edad: ");
	scanf("%d", &alum.edad);
  return alum;
}

void primeraAMayusculas(char *cadena)
{
	// otra manera de hacer may�scula el primer caracter de una cadena
	*cadena = toupper(*cadena);
}

int validarCX(char cadena[])
{
	int i;
    
	if (strlen(cadena) < 7)
		return 0;
	else
	{
		for(i = 0; i < strlen(cadena); i++)
		{
			if (!isdigit(cadena[i]))
				break;
		}
		if (i < strlen(cadena))
			return 0;
		else
			return 1;	    
	}
}

void guardarAlumno(alumno alum, char *nombreArchivo)
{
	FILE 	*p;
	
	p = fopen(nombreArchivo, "r+");
	fseek(p, 0, SEEK_END);
	fprintf(p, "%s;%s;", alum.apellido, alum.nombre);
	fprintf(p, "%s;%d\n", alum.cx, alum.edad);
    fclose(p);
}    

alumno obtenerAlumno(char cad[100])
{
	char  	edad[3];
	alumno 	alum;
	char 	separador = ';';
	int 	i, j = 0 , inicio = 0;
	int 	posiciones[3];

	for (i = inicio ; i <strlen(cad) ; i++)
	{
		if (cad[i] == separador)
		{
			posiciones[j]= i;
			j++;
		}
	}
		
	j = 0;
	for( i = 0 ;  i < posiciones[0] ; i++)
	{
		alum.apellido[j] = cad[i];
		j++;
	}
	alum.apellido[j]='\0';
	
	j = 0;
	for( i = posiciones[0]+1 ; i < posiciones[1] ; i++)
	{
		alum.nombre[j] = cad[i];
		j++;
	}
	alum.nombre[j] = '\0';
	
	j = 0;
	for( i = posiciones[1]+1 ; i < posiciones[2] ; i++)
	{
		alum.cx[j] = cad[i];
		j++;
	}
	alum.cx[j] = '\0';
	
	j = 0;
	for( i = posiciones[2]+1 ; i < strlen(cad) ; i++)
	{
		edad[j] = cad[i];
		j++;
	}
	edad[j] = '\0';
	
	alum.edad = atoi(edad);
return alum;
}

	


