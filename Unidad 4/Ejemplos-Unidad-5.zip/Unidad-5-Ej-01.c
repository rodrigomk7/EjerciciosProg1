/*  
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 1 - Archivos en C
	Declaraci�n de un puntero a FILE
*/

#include <stdio.h>

int main(int argc, char *argv[])
{
	
	FILE 	*ptrFile;
	
	printf("\n %p ", ptrFile);
	
printf("\n\n");	
return 0;	
}
