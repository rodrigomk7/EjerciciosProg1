/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 10 - Archivos en C
	Escritura y lectura en archivos de texto
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	
	FILE 	*ptrFile;
	char 	nombre[ ] = "c:\\prog1\\Ej_10_1.txt";
	char	c = 'A';

	
	ptrFile = fopen( nombre, "r+");
	
	if (ptrFile == NULL)
	{
		printf("\n El archivo no existe se creara ");
		ptrFile = ptrFile = fopen( nombre, "w+"); 
		
		if (ptrFile == NULL)
		{
			printf("\n El archivo no se pudo crear ");
			exit(1);
		}
	}
	fseek(ptrFile, 0, 2);
	fputc('\n', ptrFile);
	
	for ( ; c <='K' ; c++)
	{
		fputc(c, ptrFile);
		fputc(' ', ptrFile);
	}
	
	printf("\n\n");
	rewind(ptrFile);
	while(!feof(ptrFile))
	{
		fscanf(ptrFile,"%c", &c);
		printf("  %c", c);
	}
	
	fclose(ptrFile);
	
printf("\n\n");	
return 0;	
}
