/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 19 - Archivos en C
	Lectura y escritura en archivos de texto.
	Formateo.
*/
                                               
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, char *argv[])
{
	
	FILE 	*ptr;
	char 	nombre[ ] = "c:\\prog1\\preambuloUNT.txt";
	char	c;
	fpos_t pos;
		
	ptr = fopen( nombre, "r+");
	if (ptr == NULL)
	{
		printf("\n No se pudo abrir el archivo");
		exit(1);
	}
	
	while(!feof(ptr))
		printf("%c", fgetc(ptr));
	
	rewind(ptr);
	
	while(!feof(ptr))
	{
		if (fgetc(ptr) == ' ')
		{
			
			fgetpos(ptr, &pos);
			c = fgetc(ptr);
			fsetpos(ptr, &pos);
			fputc(toupper(c), ptr);
			fsetpos(ptr, &pos);
			
		}
	}
	
	printf("\n\n\n");
	rewind(ptr);
	while(!feof(ptr))
	{
		fscanf(ptr,"%c",&c);
		printf("%c", c);
	}
	
	fclose(ptr);
	
printf("\n\n");	
return 0;	
}
