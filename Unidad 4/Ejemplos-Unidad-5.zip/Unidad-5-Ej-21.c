/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 21 - Archivos en C
	Archivos binarios. Lectura / escritura
	
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "defStruct.h"
#include "funcRegist.h"
#include "funcFile.h"

int main(int argc, char *argv[])
{
	datos dato;
	FILE *ptrArch;
	char nombre[] = "c:\\prog1\\Ej_20_1.dat";
	long tam, pos;
	int i, b;
	
	b = apertura(nombre);
		
	if (b == 1)
		exit(1);
	ptrArch = fopen(nombre,"r+");
	
 // /* **********************************
 
	fseek(ptrArch, 0, 2);
	pos = ftell(ptrArch);
	fseek(ptrArch, 0, 0);
	tam = pos / sizeof(dato);
	
	for ( i = 0; i < tam; i++)
	{
		fread(&dato, sizeof(dato), 1, ptrArch);
		printf("\n");
		mostrarRegistro(dato);
	}
	
//	****************************** */
  /* *********************************/
	rewind(ptrArch);
	fgetc(stdin);
	while(!feof(ptrArch))
	{
		fread(&dato, sizeof(dato), 1, ptrArch);
		mostrarRegistro(dato);
	}
	
// ************************** */
	fclose(ptrArch);
printf("\n\n");
return 0;	
}
