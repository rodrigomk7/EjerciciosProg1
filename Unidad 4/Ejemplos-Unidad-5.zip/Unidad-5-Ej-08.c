/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 8 - Archivos en C
	Posicionamiento del puntero interno de archivos
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	
	FILE 	*ptrFile;
	char 	nombre[ ] = "c:\\prog1\\Ej_8_1.txt";
	
	ptrFile = fopen( nombre, "w");
	printf("\n %-50s %10p", "Direccion de memoria del puntero: ", ptrFile);
	printf("\n %-50s %10ld", "Posicion inicial del puntero interno: ", ftell(ptrFile));
	fprintf(ptrFile, "%c %c %c %c ", 'I', 'J', 'K', 'L');
	printf("\n %-50s %10ld", "Posicion del puntero interno luego de escritura: ", ftell(ptrFile));
	rewind(ptrFile);
	printf("\n %-50s %10ld", "Posicion del puntero interno luego de rewind(): ", ftell(ptrFile));
	fclose(ptrFile);
	
printf("\n\n");	
return 0;	
}
