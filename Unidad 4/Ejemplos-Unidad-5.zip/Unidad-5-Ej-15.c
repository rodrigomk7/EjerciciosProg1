/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 15
	Lectura / escritura en archivos de texto - Copia de archivos
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, char* argv[])
{
	FILE	 *pf, *temp;
	char 	c;
			
	pf = fopen("c:\\prog1\\preambuloUNT.txt", "r+");
	temp = fopen("c:\\prog1\\copia.txt", "w+");
	
	if  ( (pf == NULL) ||   (temp == NULL))
	{
		printf("\n\t\tFALLO en apertura de archivos");
		exit(1);
	}
		
		
// Copia de preambuloUNT1.txt a copia.txt
	while(!feof(pf))
		fputc(fgetc(pf), temp);	

	printf("\n\n \t  ARCHIVO ORIGEN \n");
//Muestra preambuloUNT1.txt
	rewind(pf);
	while(!feof(pf))
		printf("%c", fgetc(pf));
	
	printf("\n\n \t  ARCHIVO COPIADO \n");
//Muestra copia.txt
	rewind(temp);
	while(!feof(temp))
		printf("%c", fgetc(temp));

	fclose(pf);
	fclose(temp);
printf("\n\n");
return 0;
}
