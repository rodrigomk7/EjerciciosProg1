/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 16 - Archivos en C
	Ingresar nombre de archivo en la l�nea de �rdenes
	
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, char* argv[])
{
	FILE 	*pf;
	char 	nombre[50]="c:\\prog1\\";
		
	if(argc == 1)
	{
		printf("\n No ingreso el nombre del archivo\n\n");
		return 0;
	}
	
	strcpy(nombre,argv[1]);
	
	pf = fopen(nombre, "r+");
	if  ( (pf == NULL) )
	{		
		pf = fopen(nombre, "w+");
		if (pf == NULL)
		{
			printf("\n\t\tFALLO en apertura de archivos");
			exit(1);
		}
	}
			
	fclose(pf);
	
printf("\n\n");
return 0;
}
