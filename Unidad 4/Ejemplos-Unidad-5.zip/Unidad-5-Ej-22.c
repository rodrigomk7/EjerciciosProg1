/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 22 - Archivos en C
	Lectura / escritura de archivos binarios.
	Altas, bajas y consultas
	
*/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "defStruct.h"
#include "funcRegist.h"
#include "funcFile.h"
#include "funcFile2.h"
	
void menu(char *);

int main(int  argc, char *argv[])
{
	FILE *ptrArch;
	char nombre[] = "c:\\prog1\\datos.dat";
	
	if((ptrArch = fopen(nombre,"r+")) == NULL)
		if((ptrArch = fopen(nombre,"w+")) == NULL)
			{
		     	printf("Error de apertura de archivo");
		     	fgetc(stdin);
		     	exit(1);
		     	}
	fclose(ptrArch);
	menu(nombre);

return 0;
}

void menu(char *nomb)
{
	int opc;
	
	do {
		printf("\n\n\n\t 1. Altas ");
		printf("\n\t 2. Listar ");
		printf("\n\t 3. Ordenar ");
		printf("\n\t 4. Buscar ");
		printf("\n\t 5. Bajas ");
		printf("\n\t 6. Salir ");
		
		printf("\n\n Ingresar una opcion : ");
		scanf("%d",&opc);
		fgetc(stdin);
		
		switch(opc)
			{
			case 1 : altas(nomb);
				break;
			case 2 : listar(nomb);
				break;
			case 3 : ordenarArch(nomb);
				break;
			case 4 : buscarEnArch(nomb);
				break;
			case 5 : bajasArch(nomb);
				break;
			case 6 : break;
			default : printf("\n Opcion incorrecta");
			}
		}while(opc!=6);
	
	
return;	
}