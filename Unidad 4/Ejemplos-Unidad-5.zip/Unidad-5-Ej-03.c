/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 3 - Archivos en C
	Apertura y cierre de archivos
*/

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	
	FILE 	*pf;
	char 	nombre[ ] = "c:\\prog1\\Ej_3_1.txt";

	pf = fopen( nombre, "r+"); 
	printf("\n Archivo abre con modo r+ %p", pf);   
	fclose (pf);    // VER Linux
	
	pf = fopen( nombre, "a");
	printf("\n\n Archivo abre con modo a %p", pf);
	fclose (pf);
		
	pf = fopen( nombre, "w");
	printf("\n\n Archivo abre con modo w %p", pf);
	fclose(pf);
	
	
		
printf("\n\n");	
return 0;	
}
