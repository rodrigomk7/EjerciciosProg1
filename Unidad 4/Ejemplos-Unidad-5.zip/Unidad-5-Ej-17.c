/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 17 - Archivos en C
	Cargar datos en un archivo de texto
	
*/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "defStruct.h"
#include "funcRegist.h"
#include "funcFile.h"

int main (int argc, char *argv[])
{
	int b;
	int opc;
	char nombre[] = "c:\\prog1\\Ej_17.txt";
	
	b = apertura(nombre);
		
	if (b == 1)
		exit(1);
			
	do
	{
		printf("\n\t 1.- Agregar");
		printf("\n\t 2.- Mostrar");
		printf("\n\t 3.- Salir");
		printf("\n\n\t\t  Ingrese opcion: ");
		scanf("%d", &opc);
		switch (opc)
		{
		case 1: cargar(nombre);
			break;
		case 2: mostrarDatos(nombre);
			break;
		}	
	}while(opc != 3);
	
	printf("\n\t\t Fin del programa............................\n\n");
return 0;
}

