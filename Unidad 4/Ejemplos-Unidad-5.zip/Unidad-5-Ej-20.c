/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 20 - Archivos en C
	Escritura en archivos binarios
	
*/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "defStruct.h"
#include "funcRegist.h"
#include "funcFile.h"

int main(int argc, char *argv[])
{
	datos 	dato;
	FILE 	*ptrArch;
	char 	nombre[] = "c:\\prog1\\Ej_20_1.dat";
	int 	b;
	
	b = apertura(nombre);
		
	if (b == 1)
		exit(1);
	ptrArch = fopen(nombre,"r+");
	fseek(ptrArch, 0, 2);
	dato = leerRegistro();
	fwrite(&dato, sizeof(dato), 1, ptrArch);
	
fclose(ptrArch);
return 0;	
}
