/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 7 - Archivos en C
	Escritura en archivos de texto
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>  // para funci�n exit()

int main(int argc, char *argv[])
{
	
	FILE 	*ptr;
	char 	nombre[ ] = "c:\\prog1\\Ej_7_1.txt";

	
	ptr = fopen( nombre, "r+");
	
	if (ptr == NULL)
	{
		printf("\n El archivo no existe se creara ");
		ptr = fopen( nombre, "w+"); 
		
		if (ptr == NULL)
		{
			printf("\n El archivo no se pudo crear ");
			exit(1);
		}
	}
	printf("\n  %p", ptr);
	fprintf(ptr, " %c %c %c %c", 'a', 'b', 'c', 'd');
	
	fclose(ptr);
	
printf("\n\n");	
return 0;	
}
