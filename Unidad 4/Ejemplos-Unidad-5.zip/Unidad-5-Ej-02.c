/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 5
	
	Ejemplo 2 - Archivos en C
	Declaraci�n de punteros a FILE y apertura de archivos
*/

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	
	FILE 	*ptrF1, *ptrF2;
	FILE	*ptrF3;
	char 	nomb1[] = "c:\\prog1\\Ej_2_1.txt";
	char 	nomb2[40];

	strcpy(nomb2 , "c:\\prog1\\Ej_2_2.txt");
	
	ptrF1 = fopen( nomb1, "w");
	ptrF2 = fopen( nomb2, "r");
	ptrF3 = fopen("c:\\prog1\\Ej_2_3.txt", "a");
	
	printf("\n   %p \t   %p \t   %p", ptrF1, ptrF2, ptrF3);
	
	
	printf("\n Ingrese nombre de archivo: ");
	scanf("%s", nomb1);
	ptrF1 = fopen(nomb1, "w");
	
	printf("\n\n   %p \t   %p \t   %p", ptrF1, ptrF2, ptrF3);
	
	
	
	ptrF2 = fopen (argv[1], "w");
	printf("\n\n   %s  \n   %p \t   %p \t   %p", argv[1], ptrF1, ptrF2, ptrF3);
	

	
printf("\n\n");	
return 0;	
}
