/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1 
	
	Ejemplo N� 9
	Estructura if( ) ....
*/

#include <stdio.h>

int main(int argc, char *argv[])
{
	
	char 	car = 'x'; 		
	int 	cont_1 = 12, suma = 0;
	float 	e = 2.71828;
		
	if (car == 'x')
		printf("\n\n %c es igual que 'x'", car);
	
	if (car == 'p')
		printf("\n\n %c es igual que 'p'", car);
	
	if (cont_1)
		printf("\n\n %d es distinto que 0", cont_1);
	
	if (suma)
		printf("\n\n %c es distinta que 0", suma);
	
	if (!suma)
		printf("\n\n %d es igual que cero", suma);
	
	if (e == 2.71828)
		printf("\n\n %f es igual que 2.71828", e);
	
	if (e != 2.71828)
		printf("\n\n 2.71828 es distinto que %f", e);

printf("\n\n");
return 0;
}
