/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1
		
	Problema 2: Ingresar un valor y mostrar el factorial.
*/

#include <stdio.h> 

int main(int argc, char *argv[])
{
	
	int 	numero, factorial, i;
		
	do
	{
		printf("\nIngresar un numero: ");
		scanf("%d", &numero);
	} while(numero < 0);
	
	i = 1;
	factorial = 1;
	
	while ( i<=numero )
	{
		factorial = factorial * i;
		i += 1;  // equivale a i++  o i = i+1
	}
	
	printf("\n\t\t  %d !  = %d", numero, factorial);
	
printf("\n\n");	
return 0;
}
