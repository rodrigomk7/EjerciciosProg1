/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1
		
	Problema 4: Mostrar los n primeros numeros primos.
*/

#include <stdio.h> 

int main(int argc, char *argv[])
{
	
	int 	numero, cont;
	int 	cantDiv, n;
	int 	divisor; 
	
	cont = 1;
	numero = 2;
	
	do
	{
		printf("\nIngresar la cantidad de valores a mostrar : ");
		scanf("%d", &n);
	} while(n <= 0);

	while ( cont<n )
	{
		cantDiv = 0;
		divisor = 2;
		
		while ( divisor <= numero / 2)
		{
			if ( numero % divisor == 0)
			{
				cantDiv++;
			}
			
			divisor++;
		}
		
		if (cantDiv == 0)
		{
			printf("\n El numero %d es primo", numero);
			cont++;
		}
		
		numero++;
	}
	
printf("\n\n");	
return 0;
}
