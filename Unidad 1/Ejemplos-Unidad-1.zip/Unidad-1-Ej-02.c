/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1 
	
	Ejemplo N� 2
	Identificadores y declaraciones
*/
#include <stdio.h>

int main(int argc, char *argv[])
{
	
	// Declaraciones de variables
	char 	car; 		
	int 	cont_1, suma; 	
	float 	promedio; 	
	
	//float 		d�a; 		// Identificador no v�lido (s�mbolo �)
	// double 	30dias; 		// Identificador no v�lido (comienza con caracter num�rico)
	  int 	cont 2; 			// Identificador no v�lido (tiene espacio en blanco)

	// Sentencias
	
return 0;
}

