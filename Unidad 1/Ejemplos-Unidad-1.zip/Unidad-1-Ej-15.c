/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1 
	
	Ejemplo N� 15
	Sentencias break y continue
	
*/

#include <stdio.h>

int main(int argc, char *argv[])
{
	int 	cantidad = 7, contador;
	
 	printf("\n");
	
	for (contador = 1; contador <= cantidad; contador ++) 
	{
		
		printf("\n  %d ", contador);
		if (contador == 3) continue;
		if (contador == 5) break;
		printf("  %d ", contador);
		fgetc(stdin);
	} 
	
printf("\n\n");
return 0;
}
