/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1
		
	Problema 3: Ingresar un valor y mostrar el factorial.
*/

#include <stdio.h> 

int main(int argc, char *argv[])
{
	
	int 	numero, factorial, i;
		
	for( ; ; )
	{
		printf("\nIngresar un numero: ");
		scanf("%d", &numero);
		if (numero >= 0)
		{
			break;
		}
	} 
	
	factorial = 1;
	
	for ( i = 0 ; i<numero ;  )
	{
		factorial = factorial * ++i;
	}
	
	printf("\n\t\t  %d !  = %d", numero, factorial);
	
printf("\n\n");	
return 0;
}
