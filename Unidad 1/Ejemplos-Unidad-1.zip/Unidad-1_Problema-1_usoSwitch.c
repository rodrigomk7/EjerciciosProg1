/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1
	
	Problema 1: Calcular diferencia de potencial, intensidad de corriente o 
		     resistencia en un circuito. 
		     Utilizar un menu con la estructura switch
*/

#include <stdio.h> 

int main(int argc, char *argv[])
{
	
	int 	opcion;
	float 	difPot, resist, intens;
		
	do
	{
		printf("\n\n\t\t\t 21.- Calcular Diferencia de potencial");
		printf("\n\n\t\t\t 32.- Calcular Intensidad de corriente");
		printf("\n\n\t\t\t 43.- Calcular Resistencia");
		printf("\n\n\t\t\t 54.- Salir");
		printf("\n\n\t\t\t\t Ingrese una opcion: ");
		scanf("%d", &opcion);
		
		switch(opcion)
		{
		case 21: 
			printf(" Ingresar valor de resistencia (Ohms): ");
			scanf("%f", &resist);
			printf(" Ingresar intensidad de corriente (Amperes): ");
			scanf("%f", &intens);
			difPot = resist * intens;
			printf("\n La diferencia de potencial: %7.3f Volts", difPot);
			break;
		case 32:
			printf(" Ingresar valor de resistencia (Ohms): ");
			scanf("%f", &resist);
			printf(" Ingresar diferencia de potencial (Volts): ");
			scanf("%f", &difPot);
			intens = difPot / resist;
			printf("\n La intensidad de corriente es :%7.3f Amperes", intens);
			break;
		case 43:
			printf(" Ingresar intensidad de corriente (Amperes): ");
			scanf("%f", &intens);
			printf(" Ingresar diferencia de potencial (Volts): ");
			scanf("%f", &difPot);    
			resist = difPot/intens;
			printf("\n El valor de la resistencia es :%7.3f Ohms", resist);
			break;
		case 54:
			break;
		default:
			printf("\n Opcion NO valida ");
			break;
		}
		
	} while (opcion != 54);
	
printf("\n\n");	
return 0;
}
