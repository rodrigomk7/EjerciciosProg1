/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1 
	
	Ejemplo N� 11
	Estructura switch (...) { ... }
	
*/

#include <stdio.h>

int main(int argc, char *argv[])
{
	int 	opcion;
 	
	printf("\n Ingrese una valor entero entre 1 y 5: ");
	scanf("%d", &opcion);
	
	switch(opcion)
	{
		case 1: printf("\n Ingreso 1");
			break;
		case 2: printf("\n Ingreso 2");
			//break;
		case 3: printf("\n Ingreso 3");
			//break;
		case 4: printf("\n Ingreso 4");
			break;
		case 5: printf("\n Ingreso 5");
			break;
		default: printf("\n Ingreso un valor menor que 1 o mayor que 5"); 
	}
	
printf("\n\n");
return 0;
}
