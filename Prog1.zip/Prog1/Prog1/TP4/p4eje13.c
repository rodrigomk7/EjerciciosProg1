/* p4 eje 13 - intercambiar la diagonal principal por la
diagonal secundaria*/


#include<stdio.h>


void cargar_matriz(int,int A[][50]);
void mostrar_matriz(int,int A[][50]);
void intercambiar_prim_x_sec(int,int A[][50]);

int main (int argc, char *argv[])
{
int m;
int A[50][50];
do
{
printf("\n ingrese el num. de filas de una matriz caud:");
scanf("%d",&m);
}while(m<=0);


cargar_matriz(m,A);
printf("\n antes del intercambio: \n");
mostrar_matriz(m,A);
intercambiar_prim_x_sec(m,A);
mostrar_matriz(m,A);

return 0;
}




void cargar_matriz(int m,int A[][50])
{
int i,j,h=1,k=1;
for(i=0;i<m;i++)
	{
	k=1;
	for(j=0;j<m;j++)
		{
		printf("\nIngrese el elemento Mat[%d][%d]:  ",h,k++);
		scanf("%d",&A[i][j]);
		}
		h++;
	}
}
 

void mostrar_matriz(int m,int A[][50])
{
int i,j;
printf("\n\n");
for(i=0;i<m;i++)
	{
	for(j=0;j<m;j++)
		{
		printf("\t %d",A[i][j]);
		}
		printf("\n\n");
	}
}



void intercambiar_prim_x_sec(int m,int A[][50])
{

int i,aux=0;
m=m-1;

for(i=0;i<=m;i++)
  {
  
         aux = A[i][i];
     A[i][i] = A[i][m-i];
     A[i][m-i] = aux;
 }
 printf("\n despues del intercambio: \n ");
}      
