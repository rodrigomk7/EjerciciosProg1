#include<stdio.h>
#include"fn_vectores_roh.h"
int main(int argc, char *argv[])
{
int n,ban=0;
char a,b,vect[50];
printf("\n orden:");
scanf("%d",&n);
getchar();
cargar_vector_char(n,vect);
mostrar_vector_char(n,vect);
do{
printf("\n ingrese una letra:");
scanf("%c",&a);
getchar();
ban=buscar_elemento_car(a,n,vect);
}while(ban!=1);
printf(" ingrese un valor para cambiar ");
scanf("%c",&b);
getchar();
reemplazar_caracter_en_vector(a,b,n,vect);
mostrar_vector_char(n,vect);
}