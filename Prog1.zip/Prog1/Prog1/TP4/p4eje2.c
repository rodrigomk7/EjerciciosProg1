#include<stdio.h>

void cargar_vector(int*, int*);
void mostrar_vector(int*, int *);
int es_primo(int);

int main(int argc, char *argv[])
{
int *n;
int vect[50];

cargar_vector(n,vect);
mostrar_vector(n,vect);

return 0;
}

void cargar_vector(int *n, int vect[])
{
int i=0,x,ban=0;

for(x=10;x<100;x++)
{
   ban=es_primo(x);

   if(ban==1)
   {
   vect[i]=x;
   i++;
   }
}
*n=i;
}

int es_primo(int x)
{
int div=2,cont=0;

for(;x>div;div++)
{
if(x%div==0)
cont++;
}
if(cont==0)
return 1;
else
return 0;
}

void mostrar_vector(int *n, int vect[])
{
int i=0;
for(;i<*n;i++)
{
printf(" %d ", vect[i]);
}
printf("\n \n");
}
