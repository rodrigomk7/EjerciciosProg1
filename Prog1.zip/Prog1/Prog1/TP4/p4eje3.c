#include<stdio.h>

void cargar_vector(int,int*);
void mostrar_vector(int,int*);
void insertar_elemento(int,int*, int*);


int main(int argc,char *argv[])
{
int n;
int vect[100], vectm[100];

do
{
printf("\n ingrese el orden del vector:");
scanf("%d",&n);
}while(n<=0);

cargar_vector(n,vect);
mostrar_vector(n,vect);
insertar_elemento(n,vect,vectm);
mostrar_vector(n+1,vectm);
return 0;
}




void cargar_vector(int n, int vect[])
{
int i=0,c=1;
for(;i<n;i++)
{
printf(" \n ingrese el elemento %d del vector: ",c++);
scanf("%d",&vect[i]);
}
}

void mostrar_vector(int n, int vect[])
{
int i=0;
printf("\n\t\t");
for(;i<n;i++)
{
printf("  %d ", vect[i]);
}
printf("\n \n");
}


void insertar_elemento(int n,int vect[],int vectm[])
{
int i=0,x,p,e=0,aux=0;

printf("\n ingrese un valor: ");
scanf("%d",&x);

do
{
printf("\n ingrese la posicion en la q lo desea insertar:");
scanf("%d",&p);
}while(x>n&&x<0);
--p;

for(;i<=n;i++)
{
        if(i<p)
        {
           vectm[e]=vect[i];  
        }
        else
        {
                if(i==p)
                {
                aux=vect[i];
                vectm[e]=x;
                }
              else
                {
                vectm[e]=aux;
                aux=vect[i];
                }
        }
        e++;
}
       
}











