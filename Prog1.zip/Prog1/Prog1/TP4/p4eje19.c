/* p4 eje 19 - intercambiar los elementos de un vector
con los diagonal principal de una matriz*/
#include<stdio.h>


void cargar_matriz(int,int A[][50]);
void mostrar_matriz(int,int A[][50]);
void cargar_vector(int,int *);
void mostrar_vector(int,int*);
void inter_vec_x_dia_princ(int,int*, int A[][50]);


int main (int argc, char *argv[])
{
int n;
int A[50][50], v[50];
do
{
printf("\n ingrese el orden del vector:");
scanf("%d",&n);
}while(n<=0);

cargar_vector(n,v);
cargar_matriz(n,A);

printf("\n los arreglos cargados son: \n");
mostrar_vector(n,v);
mostrar_matriz(n,A);

inter_vec_x_dia_princ(n,v,A);

printf("\n los arreglos modificados son:");
mostrar_vector(n,v);
mostrar_matriz(n,A);

return 0;
}

void cargar_vector(int n,int v[])
 {
 int i,g=1;
 
 for(i=0;i<n;i++)
      {
          printf("\n ingrese el elemento vect[%d]: ",g++);
          scanf("%d",&v[i]);
      }
 } 


void cargar_matriz(int n,int A[][50])
{
int i,j,h=1,k=1;
for(i=0;i<n;i++)
	{
	k=1;
	for(j=0;j<n;j++)
		{
		printf("\nIngrese el elemento Mat[%d][%d]:  ",h,k++);
		scanf("%d",&A[i][j]);
		}
		h++;
	}
}
 

void mostrar_matriz(int n,int A[][50])
{
int i,j;
printf("\n\n la matriz es:\n\n");
for(i=0;i<n;i++)
	{
	for(j=0;j<n;j++)
		{
		printf("\t%d",A[i][j]);
		}
		printf("\n\n");
	}}

void mostrar_vector(int n,int v[])
 {
 int i;
 printf("\n\n el vector es:\n\n");
 for(i=0;i<n;i++)
 {
  printf("\t%d",v[i]); }} 



void inter_vec_x_dia_princ(int n,int v[], int A[][50])
{
int i,aux;

for(i=0;i<n;i++)
        {
         aux=v[i];
         v[i]=A[i][i];
         A[i][i]=aux;
         }
}













