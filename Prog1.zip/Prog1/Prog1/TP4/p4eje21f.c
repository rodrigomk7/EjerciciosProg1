/*  p4 eje 21 - generar un vector con los numeros
 primos de una matriz*/

#include<stdio.h>
#include<time.h>
#include<math.h>
#include "func_vectores.h"
#include "func_matrices.h"

int generar_vec_primo(int,int,int A[][30],int *);
int es_primo(int);


int main (int argc, char *argv[])
{
int m,n,orden;
int A[30][30] , v[10];
do
{
printf("\n ingrese el num. de filas de la matriz:");
scanf("%d",&m);
}while(m<=0);
do
{
printf("\n ingrese el num. de columnas de la matriz:");
scanf("%d",&n);
}while(n<=0);

cargaAlMatInt(m,n,A);
printf("\n la matriz cargada es: \n");
verMatInt(m,n,A);

orden=generar_vec_primo(m,n,A,v);
if(orden!=0)
{
printf("\n el vector primo es:\n\t\t\t\t");
verVectInt(orden,v);
}
else
printf("\n NO hay primos");
return 0;
}



int generar_vec_primo(int m,int n,int A[][30],int v[])
{
int i,j,ban,e=0,c=0,h=0;

for(i=0;i<m;i++)
{
        for(j=0;j<n;j++)
        {
        h++;
        ban=es_primo(A[i][j]);

              if(ban==7)
                 {
                    v[e]=A[i][j];
                    e++;
                 }
                 else
                 c++;
         }        
 }
 if(c!=h)
 return e;
 else
 return 0;
}
        

int es_primo(int x)
{
int d=2,cont=0;

while(x>d)
{
if(x%d==0)
cont++;
d++;
}
if(cont==0)
          return 7;
else
          return 0;
}
