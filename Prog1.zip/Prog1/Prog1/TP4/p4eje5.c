/* p4-eje_5 */

#include<stdio.h>

void cargar_vector(int, int*);
void reemplazar_valor(int, int*);
void mostrar_vector(int,int*);

int main(int argc, char *argv[])
{
int n;
int vect[100];
do
{
printf("\n Ingrese el orden del vector: ");
scanf("%d",&n);
}while(n<=0);

cargar_vector(n,vect);
mostrar_vector(n,vect);
reemplazar_valor(n,vect);
mostrar_vector(n,vect);

return 0;
}

void cargar_vector(int n, int vect[])
{
int i=0,c=1;
for(;i<n;i++)
{
printf(" \n ingrese el elemento %d del vector: ",c++);
scanf("%d",&vect[i]);
}
}

void mostrar_vector(int n, int vect[])
{
int i=0;
printf("\n\t\t");
for(;i<n;i++)
{
printf("  %d ", vect[i]);
}
printf("\n \n");
}

void reemplazar_valor(int n, int vect[])
{
int e,x,i;

printf("\n Ingrese un valor a reeplazar:  ");
scanf("%d",&e);
do
{
printf("\n ingrese la posicion del elemento a reeplazar:  ");
scanf("%d",&x);
}while(0>x && x>=n);
--x;

for(i=0;i<n;i++)
 {
        if(x==i)
        {
        //--i;
        vect[i]=e;
        }
 }
}
