/* p4-eje_4 */

#include<stdio.h>

void cargar_vector(int, int*);
void eliminar_elemento(int,int*,int*);
void mostrar_vector(int,int*);
void mostrar_vector_gen(int,int*);

int main(int argc, char *argv[])
{
int n;
int vect[100];
int vectm[100];
do
{
printf("\n Ingrese el orden del vector: ");
scanf("%d",&n);
}while(n<=0);

cargar_vector(n,vect);
mostrar_vector(n,vect);
eliminar_elemento(n,vect,vectm);
mostrar_vector_gen(n,vectm);

return 0;
}

void cargar_vector(int n, int vect[])
{
int i=0,c=1;
for(;i<n;i++)
{
printf(" \n ingrese el elemento %d del vector: ",c++);
scanf("%d",&vect[i]);
}
}

void mostrar_vector(int n, int vect[])
{
int i=0;
printf("\n\t\t");
for(;i<n;i++)
{
printf("  %d ", vect[i]);
}
printf("\n \n");
}


void mostrar_vector_gen(int n, int vect[])
{
int i=0;
printf("\n\t\t");
for(;i<n-1;i++)
{
printf("  %d ", vect[i]);
}
printf("\n \n");
}



void eliminar_elemento(int n,int vect[],int vectm[])
{
int x,i,e=0;
//int vecmod[100];
do
{
printf("\n ingrese la posicion del elemento a eliminar:  ");
scanf("%d",&x);
}while(0>x && x>=n);
--x;

for(i=0;i<n;i++)
 {
        if(x==i)
        {
         
        vectm[e]=vect[++i];
        }
        else
        vectm[e]=vect[i];
        e++;
    }
 // n=e;
}
