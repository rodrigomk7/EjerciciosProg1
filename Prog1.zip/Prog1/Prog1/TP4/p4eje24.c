/*  p4 eje 24 - generar un vector con el promedio de las filas
y otro el de las columnas*/

#include<stdio.h>
void cargar_matriz(int,int,int A[][50]);
void mostrar_matriz(int,int,int A[][50]);
void generar_vec_prom_filas(int,int,int A[][50],float *);
void generar_vec_prom_columnas(int,int,int A[][50],float *);
void mostrar_vector(int,float*);


int main (int argc, char *argv[])
{
int m,n,orden;
int A[50][50];
float vc[50],vf[50];
do
{
printf("\n ingrese el num. de filas de la matriz:");
scanf("%d",&m);
}while(m<=0);
do
{
printf("\n ingrese el num. de columnas de la matriz:");
scanf("%d",&n);
}while(n<=0);

cargar_matriz(m,n,A);
printf("\n la matriz cargada es: \n");
mostrar_matriz(m,n,A);

generar_vec_prom_filas(m,n,A,vf);
printf("\n el vector promedio de las filas es: \n");
mostrar_vector(m,vf);

generar_vec_prom_columnas(m,n,A,vc);
printf("\n el vector promedio de las columnas es: \n");
mostrar_vector(n,vc);

return 0;
}




void cargar_matriz(int m,int n,int A[][50])
{
int i,j,h=1,k=1;

for(i=0;i<m;i++)
	{
	k=1;
	for(j=0;j<n;j++)
		{
		printf("\nIngrese el elemento Mat[%d][%d]:  ",h,k++);
		scanf("%d",&A[i][j]);
		}
		h++;
	}}
 

void mostrar_matriz(int m,int n,int A[][50])
{
int i,j;
printf("\n\n");
for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
		{
		printf("\t %d",A[i][j]);
		}
		printf("\n\n");
	}}

void mostrar_vector(int n,float v[])
 {
 int i;
 for(i=0;i<n;i++)
 {
  printf("%5.2f  ",v[i]);}} 

void generar_vec_prom_filas(int m,int n,int A[][50], float vf[])
{
int i,j,e=0;
float sum;
for(i=0;i<m;i++)
        {
        sum=0;
        for(j=0;j<n;j++)
           {
           sum=sum+A[i][j];
           }
           vf[i]=sum/n;
        }
}

void generar_vec_prom_columnas(int m,int n,int A[][50],float vc[])
{
float sum;
int i,j;
for(j=0;j<n;j++)
        {
        sum=0;
        for(i=0;i<m;i++)
           {
           sum=sum+A[i][j];
           }
           vc[j]=sum/m;
           
        }
}

        
  
  
