// p4-eje5 - como pedia el ejecicio


#include<stdio.h>
#include"fn_vectores_roh.h"
#include"control_roh.h"

int control(int x,int n);
void reemplazar_elemen(int pos,float x, int *n, float v[]);

int main (int argc, char *argv[])
{
int n,b=0,pos;
float x, v[50];


do
{
printf("\n ingrese orden:  ");
scanf("%d",&n);
b=icontrol_pos_int(n);
}while(b==0);

cargar_vector_float(n,v);
printf("\n el vector ingresado es: ");
mostrar_vector_float(n,v);

printf("\n ingrese un valor: ");
scanf("%f",&x);
do
{
	printf("\n ingrese la posicion:");
	scanf("%d",&pos);
	b=control(pos,n);
}while(b==0);

reemplazar_elemen(pos-1,x,&n,v);

printf("\n el vector modificado es: ");

mostrar_vector_float(n,v);

return 0;
}

int control(int x,int n)
{
	if(x>0 && x<=n)
		return 1;
	else
		return 0;
}


/* reemplazar un elemento real ingresado
 en la posicion de un elemento de un vector real */ 

void reemplazar_elemen(int pos,float x, int *n, float v[])
{
int i;
	for(i=0;i<*n;i++)
	{
	if(i==pos)
	   v[i]=x;
	}
}