/* p4 eje 14 - buscar y contar un valor en uma matriz */


#include<stdio.h>


void cargar_matriz(int,int,int A[][50]);
void mostrar_matriz(int,int,int A[][50]);
void buscar_y_contar(int,int,int A[][50]);

int main (int argc, char *argv[])
{
int m,n;
int A[50][50];
do
{
printf("\n ingrese el num. de filas de la matriz:");
scanf("%d",&m);
}while(m<=0);
do
{
printf("\n ingrese el num. de columnas de la matriz:");
scanf("%d",&n);
}while(n<=0);


cargar_matriz(m,n,A);
mostrar_matriz(m,n,A);
buscar_y_contar(m,n,A);

return 0;
}




void cargar_matriz(int m,int n,int A[][50])
{
int i,j,h=1,k=1;
for(i=0;i<m;i++)
	{
	k=1;
	for(j=0;j<n;j++)
		{
		printf("\nIngrese el elemento Mat[%d][%d]:  ",h,k++);
		scanf("%d",&A[i][j]);
		}
		h++;
	}
}
 

void mostrar_matriz(int m,int n,int A[][50])
{
int i,j;
printf("\n\n");
for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
		{
		printf("\t %d",A[i][j]);
		}
		printf("\n\n");
	}
}



void buscar_y_contar(int m,int n,int A[][50])
{
int i,j,cont=0,x;

printf("\n ingrese el valor a buscar:");
scanf("%d",&x);

for(i=0;i<m;i++)
   {
   for(j=0;j<n;j++)
        {
        if(x==A[i][j])
        cont++;
        }
   }

   if(cont>0)
   printf("\n se encontro %d veces el valor %d",cont,x);
   else
   printf("\n no se encontro el valor %d ", x);

printf("\n\n");

   }
   




