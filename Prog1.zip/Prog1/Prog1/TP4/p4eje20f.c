/*  p4 eje 20 - generar un vector con los numeros
 triangulares de una matriz*/

#include<stdio.h>
#include<time.h>
#include<math.h>
#include "func_vectores.h"
#include "func_matrices.h"


int generar_vec_tringular(int,int,int A[][30],int *);
int es_tringular(int);


int main (int argc, char *argv[])
{
int m,n,orden;
int A[30][30] , v[10];
do
{
printf("\n ingrese el num. de filas de la matriz:");
scanf("%d",&m);
}while(m<=0);
do
{
printf("\n ingrese el num. de columnas de la matriz:");
scanf("%d",&n);
}while(n<=0);

cargaAlMatInt(m,n,A);
printf("\n la matriz cargada es: \n");
verMatInt(m,n,A);

orden=generar_vec_tringular(m,n,A,v);
if(orden!=0)
{
printf("\n el vector triangular es:\n\t\t\t\t");
verVectInt(orden,v);
}
else
printf("\n no hay triangulares");

return 0;
}






int generar_vec_tringular(int m,int n,int A[][30],int v[])
{
int i,j,ban,e=0,c=0,h=0;

for(i=0;i<m;i++)
{
        for(j=0;j<n;j++)
        {
        h++;
        ban=es_triangular(A[i][j]);

              if(ban==7)
                 {
                    v[e]=A[i][j];
                    e++;
                 }
                 else
                 c++;
         }        
 }
 if(c!=h)
 
 return e;
 else
 return 0;
}
        

int es_triangular(int x)
{
int po=2,tri=1;

while(tri<x)
{
tri=po+tri;
po++;
}
if(tri==x)
          return 7;
else
          return 0;
}
