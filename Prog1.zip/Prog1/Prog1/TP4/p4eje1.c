/* p4 - eje 1 - cargar un vector e invertirlo sin usar un arreglo auxiliar */

#include<stdio.h>
void cargar_vector(int, int *);
void mostrar_vector(int, int *);
void invertir_vector(int, int *);

int main(int argc, char* argv[])
{
int n;int vect[100];
do
{
printf("\n ingrese el orden del vector: ");
scanf("%d",&n);
}while(n<=0);



cargar_vector(n,vect);
mostrar_vector(n,vect);

invertir_vector(n,vect);
mostrar_vector(n,vect);
return 0;
}


void cargar_vector(int n, int vect[])
{
int i=0;
for(;i<n;i++)
{
printf(" \n ingrese un elemento del vector: ");
scanf("%d",&vect[i]);
}
}

void mostrar_vector(int n, int vect[])
{
int i=0;
for(;i<n;i++)
{
printf(" %d ", vect[i]);
}
printf("\n \n");

}

void invertir_vector(int n, int vect[])
{
int i=0,aux,r;
r=n-1;

for(;i<(n/2);)
{
aux=vect[i];
vect[i]=vect[r];
vect[r]=aux;
r--;
i++;
}
}






