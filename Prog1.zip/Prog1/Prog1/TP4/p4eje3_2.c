/* p4_eje 3 -sin usar vector auxiliar */

#include<stdio.h>
#include"fn_vectores_roh.h"
#include"control_roh.h"
int control(int x,int n);
void insertar(int valor,int pos,int *n,int v[]);

int main (int argc, char *argv[])
{
int v[50],n,b=0,valor,pos;
do
{
printf("\n ingrese orden");
scanf("%d",&n);
b=icontrol_pos_int(n);
}while(b==0);

cargar_vector_int(n,v);
mostrar_vector_int(n,v);

printf("\n ingrese un valor:");
scanf("%d",&valor);
do
{
	printf("\n ingrese la posicion:");
	scanf("%d",&pos);
	b=control(pos,n);
}while(b==0);

insertar(valor,pos-1,&n,v);

mostrar_vector_int(n,v);

return 0;
}

int control(int x,int n)
{
	if(x>0 && x<=n)
		return 1;
	else
		return 0;
}

/* insertar un elemento en un vector 
sin vector auxiliar*/
void insertar(int valor,int pos,int *n,int v[])
{
	int i,aux=0,aux1=0;
	for(i=0;i<(*n);i++)
	{
			if(i==pos)
			{
				aux=v[i];
				v[i]=valor;
				(*n)=(*n)+1;
			}
			else
			{
				if(i>pos)
				{
					aux1=v[i];
					v[i]=aux;
					aux=aux1;
				}
			}
	}
}