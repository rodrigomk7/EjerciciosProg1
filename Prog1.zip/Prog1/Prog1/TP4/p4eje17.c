/* p4 eje 17 - insertar un vector en el
 medio de una matriz*/

#include<stdio.h>

void cargar_matriz(int*,int,int A[][50]);
void mostrar_matriz(int*,int,int A[][50]);
void insertar_vector(int*,int,int A[][50],int*);
void cargar_vector(int,int*);


int main (int argc, char *argv[])
{
int *m,n,x;
int A[50][50] , v[50];
do
{
printf("\n ingrese el num. de filas de la matriz:");
scanf("%d",&x);
}while(x%2!=0);
do
{
printf("\n ingrese el num. de columnas de la matriz:");
scanf("%d",&n);
}while(n<=0);
m=&x;
cargar_matriz(m,n,A);
printf("\n la matriz cargada es: \n");
mostrar_matriz(m,n,A);
cargar_vector(n,v);

insertar_vector(m,n,A,v);
printf("\n la matriz generada es: \n");

mostrar_matriz(m,n,A);

return 0;
}




void cargar_matriz(int *m,int n,int A[][50])
{
int i,j,h=1,k=1;

for(i=0;i<*m;i++)
	{
	k=1;
	for(j=0;j<n;j++)
		{
		printf("\nIngrese el elemento Mat[%d][%d]:  ",h,k++);
		scanf("%d",&A[i][j]);
		}
		h++;
	}
}
 

void mostrar_matriz(int *m,int n,int A[][50])
{
int i,j;
printf("\n\n");
for(i=0;i<*m;i++)
	{
	for(j=0;j<n;j++)
		{
		printf("\t %d",A[i][j]);
		}
		printf("\n\n");
	}
}


void cargar_vector(int n,int v[])
 {
 int i,g=1;
 
 for(i=0;i<n;i++)

         {
          printf("\n ingrese el elemento vect[%d]: ",g++);
          scanf("%d",&v[i]);
         }
 } 


void insertar_vector(int *m,int n ,int A[][50],int v[])
{

  int i,j;
 for(i=*m;i>*m/2;i--)
 {
        for(j=0;j<n;j++)
         {A[i][j]=A[i-1][j];
         }
 }
 for(j=0;j<n;j++)
 { 
 A[i][j]=v[j];
 }
 *m=*m+1; 
}         


 

