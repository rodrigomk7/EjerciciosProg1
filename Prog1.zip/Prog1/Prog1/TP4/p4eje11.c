/* p4 eje 11- sumar los elementos q estan de bajo de la diagonal sec*/


#include<stdio.h>


void cargar_matriz(int,int,int A[][50]);
void mostrar_matriz(int,int,int A[][50]);
void sumar_elementos(int,int A[][50]);

int main (int argc, char *argv[])
{
int p,m;
int A[50][50];
do
{
printf("\n ingrese el n° de filas:");
scanf("%d",&p);
}while(p<=0);

m=p;
 
cargar_matriz(p,m,A);
mostrar_matriz(p,m,A);
sumar_elementos(m,A);

return 0;
}




void cargar_matriz(int m,int n,int A[][50])
{
int i,j,h=1,k=1;
for(i=0;i<m;i++)
	{
	k=1;
	for(j=0;j<n;j++)
		{
		printf("\nIngrese el elemento Mat[%d][%d] : ",h,k++);
		scanf("%d",&A[i][j]);
		}
		h++;
	}
}
 

void mostrar_matriz(int m,int n,int A[][50])
{
int i,j;

for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
		{
		printf("\t%d",A[i][j]);
		}
		printf("\n\n");
	}
}


void sumar_elementos(int m,int A[][50])
{
	int i,j,s=0;
m=m-1;

i=m;
while(i>0)
{
   j=m;
   while(j>=m-i+1)
        {
        s=s+A[i][j];
        j=m-1;
        }
i=m-1;
}
	
printf("\n el valor de la suma es: %d", s);
  
}
  
