/* p4 eje 12*/

#include<stdio.h>


void cargar_matriz(int,int,int A[][50]);
void mostrar_matriz(int,int,int A[][50]);
void intercambiar_columnas(int,int,int A[][50]);

int main (int argc, char *argv[])
{
int m,n;
int A[50][50];
do
{
printf("\n ingrese el n° de filas:");
scanf("%d",&m);
}while(m<=0);
do
{
printf("\n ingrese el n° de columnas:");
scanf("%d",&n);
}while(n<=0);

cargar_matriz(m,n,A);
mostrar_matriz(m,n,A);
intercambiar_columnas(m,n,A);
mostrar_matriz(m,n,A);

return 0;
}




void cargar_matriz(int m,int n,int A[][50])
{
int i,j,h=1,k=1;
for(i=0;i<m;i++)
	{
	k=1;
	for(j=0;j<n;j++)
		{
		printf("\nIngrese el elemento Mat[%d][%d]:  ",h,k++);
		scanf("%d",&A[i][j]);
		}
		h++;
	}
}
 

void mostrar_matriz(int m,int n,int A[][50])
{
int i,j;
printf("\n\n");
for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
		{
		printf("\t %d",A[i][j]);
		}
		printf("\n\n");
	}
}



void intercambiar_columnas(int m,int n,int A[][50])
{
int a,b,i,j,aux;

do
{
printf("\n ingrese el un num. de columna:");
scanf("%d",&a);
}while(a<=0 &&  a>n);
do
{
printf("\n ingrese nuevamente el un num. de columna:");
scanf("%d",&b);
}while(b<=0 && b>n);
--a;
--b;

for(i=0;i<m;i++)
{
           aux=A[i][a];
           A[i][a]=A[i][b];
           A[i][b]=aux;
           
 }
}




