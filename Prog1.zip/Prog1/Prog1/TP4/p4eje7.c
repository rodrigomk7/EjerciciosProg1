/* p4 - eje 7 - buscar el mayor elemento par y el mrnor elemento impar y
sus posiciones */

#include<stdio.h>

void cargar_vector(int,int*);
void mostrar_vector(int,int*);
void buscar_par(int, int*);
void buscar_impar(int,int*);


int main(int argc,char *argv[])
{
int n;
int vect[100];

do
{
printf("\n ingrese el orden del vector:");
scanf("%d",&n);
}while(n<=0);

cargar_vector(n,vect);
mostrar_vector(n,vect);
buscar_par(n,vect);
buscar_impar(n,vect);
return 0;
}




void cargar_vector(int n, int vect[])
{
int i=0,c=1;
for(;i<n;i++)
{
printf(" \n ingrese el elemento %d del vector: ",c++);
scanf("%d",&vect[i]);
}
}

void mostrar_vector(int n, int vect[])
{
int i=0;
printf("\n\t\t");
for(;i<n;i++)
{
printf("  %d ", vect[i]);
}
printf("\n \n");
}

void buscar_par(int n, int vect[])
{
int i=0,cont=0,may,pmay;
for(;i<n;i++)
{
 if(vect[i]%2==0)
 {
        if(cont==0)
        {
        may=vect[i];
        pmay=i;
        cont++;
        }
        else
        {
        if(may<vect[i])
                {
                may=vect[i];
                pmay=i;
                }
        }
 }
 }
 if(cont!=0)
 printf("\n el mayor valor par es %d e ingreso en la posicion %d \n \n",may,++pmay);
 else
 printf("\n NO SE INGRESARON VALORES PARES \n \n");
}

 
void buscar_impar(int n, int vect[])
{
int i=0,cont=0,men,pmen;
for(;i<n;i++)
{
 if(vect[i]%2!=0)
 {
        if(cont==0)
        {
        men=vect[i];
        pmen=i;
        cont++;
        }
        else
        {
        if(men>vect[i])
                {
                men=vect[i];
                pmen=i;
                }
        }
 }
 }
 if(cont!=0)
 printf("\n el menor valor impar es %d e ingreso en la posicion %d \n \n",men,++pmen);
 else
 printf("\n NO SE INGRESARON VALORES IMPARES \n \n");
}       








