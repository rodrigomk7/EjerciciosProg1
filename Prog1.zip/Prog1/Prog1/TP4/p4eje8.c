/* p4-  eje 8 - intercambiar el mayor valor con el menor valor*/

#include<stdio.h>

void cargar_vector(int,int*);
void mostrar_vector(int,int*);
void intercambio_may_x_men(int, int*);


int main(int argc,char *argv[])
{
int n;
int vect[100];

do
{
printf("\n ingrese el orden del vector:");
scanf("%d",&n);
}while(n<=0);

cargar_vector(n,vect);
mostrar_vector(n,vect);
intercambio_may_x_men(n,vect);
return 0;
}




void cargar_vector(int n, int vect[])
{
int i=0,c=1;
for(;i<n;i++)
{
printf(" \n ingrese el elemento %d del vector: ",c++);
scanf("%d",&vect[i]);
}
}

void mostrar_vector(int n, int vect[])
{
int i=0;
printf("\n\t\t");
for(;i<n;i++)
{
printf("  %d ", vect[i]);
}
printf("\n \n");
}


void intercambio_may_x_men(int n, int vect[])
{
int i=0, cont=0,aux,may,men,pmay,ban=0,pmen;

for(;i<n;i++)
{
  if(i==0)
  {
  may=vect[i];
  men=vect[i];
  pmay=i;
  pmen=i;
  }
  else
  {
    if(may<vect[i])
    {
    may=vect[i];
    pmay=i;
    }
    else
       {
       if(men>vect[i])
             {
             men=vect[i];
             pmen=i;
             }
       }
   }
 }

 
 if(may!=men)
 {
 vect[pmen]=may;
 vect[pmay]=men;
 
 mostrar_vector(n,vect);
 }
 else
 printf("\n los elementos son todos iguales \n ");
}
         













