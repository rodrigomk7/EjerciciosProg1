/*p4 eje 18 - generar un vector con los elementos q estan debajo
de la diagonal secundaria */

#include<stdio.h>


void cargar_matriz(int,int A[][50]);
void mostrar_matriz(int,int A[][50]);
void gene_vec_elem_x_debajo_diaSec(int,int A[][50],int *,int*);
void mostrar_vector(int*,int*);


int main (int argc, char *argv[])
{
int m, *p;
int A[50][50] , v[50];
do
{
printf("\n ingrese el num. de filas de la matriz:");
scanf("%d",&m);
}while(m<=0);

cargar_matriz(m,A);
printf("\n la matriz cargada es: \n");
mostrar_matriz(m,A);

gene_vec_elem_x_debajo_diaSec(m,A,v,p);
printf("\n el vector generado es: \n\t\t\t\a");
mostrar_vector(p,v);
return 0;
}




void cargar_matriz(int m,int A[][50])
{
int i,j,h=1,k=1;

for(i=0;i<m;i++)
	{
	k=1;
	for(j=0;j<m;j++)
		{
		printf("\nIngrese el elemento Mat[%d][%d]:  ",h,k++);
		scanf("%d",&A[i][j]);
		}
		h++;
	}
}
 

void mostrar_matriz(int m,int A[][50])
{
int i,j;
printf("\n\n");
for(i=0;i<m;i++)
	{
	for(j=0;j<m;j++)
		{
		printf("\t %d",A[i][j]);
		}
		printf("\n\n");
	}
}


void mostrar_vector(int *p,int v[])
 {
 int i;
       for(i=0;i<*p;i++)
        {
        printf("%d\t",v[i]);
        }
 }

void gene_vec_elem_x_debajo_diaSec(int m,int A[][50],int v[],int *p)
{
 int i,j,e=0;
m=m-1;
 for(j=m;j>0;j--)
  {
        i=m-j+1;
        for(;i<=m;i++)
              {
              v[e]=A[i][j];
              e++;
              }
  }
  *p=e;
}
  
