/* p4 eje 15 - ordenar en forma ascendente
 la diagonal principal y secundaria*/
#include<stdio.h>


void cargar_matriz(int,int A[][50]);
void mostrar_matriz(int,int A[][50]);
void ord_asce_dia_princi(int,int A[][50]);
void ord_asce_dia_secundaria(int,int A[][50]);


int main (int argc, char *argv[])
{
int m;
int A[50][50];
do
{
printf("\n ingrese el num. de filas de una matriz cuadr.:");
scanf("%d",&m);
}while(m%2!=0);

cargar_matriz(m,A);
printf("\n la matriz cargada es: \n");
mostrar_matriz(m,A);
ord_asce_dia_princi(m,A);
ord_asce_dia_secundaria(m,A);
printf("\n despues del ordenamiento:");
mostrar_matriz(m,A);
return 0;
}




void cargar_matriz(int m,int A[][50])
{
int i,j,h=1,k=1;
for(i=0;i<m;i++)
	{
	k=1;
	for(j=0;j<m;j++)
		{
		printf("\nIngrese el elemento Mat[%d][%d]:  ",h,k++);
		scanf("%d",&A[i][j]);
		}
		h++;
	}
}
 

void mostrar_matriz(int m,int A[][50])
{
int i,j;
printf("\n\n");
for(i=0;i<m;i++)
	{
	for(j=0;j<m;j++)
		{
		printf("\t %d",A[i][j]);
		}
		printf("\n\n");
	}
}

void ord_asce_dia_princi(int m,int A[][50])
{
int i,j,aux,men;

for(i=0;i<m;i++)
     {
          for(j=i+1;j<m;j++)
          {
          if(A[i][i] > A[j][j])
          {
          aux=A[i][i];
          A[i][i]=A[j][j];
          A[j][j]=aux;
          }
          }
             
     }
}



void ord_asce_dia_secundaria(int m,int A[][50])
{


int i,j,aux,k,r,x,y;

	m=m-1;
	
	for(i=0;i<=m;i++)
	{
	
        	j=m-i;
		r=i;
		k=j;

			
		while(k>0)
		{
	          x=r+1;
	          y=k-1;
			
			if(A[i][j]<A[x][y])
			      {
				aux=A[i][j];
				A[i][j]=A[x][y];
				A[x][y]=aux;
			      }			
		   r++;
		   k--;
		}
	}
}


