#include<stdio.h>
#include<ctype.h>
#include"fn_vectores_roh.h"


int main(int argc, char *argv[])
{
int *n,x,ban=0;
int vec[50];
printf("\n ingrese el orden :  ");
scanf("%d",&x);

cargar_vector_int(x,vec);
mostrar_vector_int(x,vec);
n=&x;
 ban=control_repetidos_int(x,vec);
 if(ban==1)
 {
 eliminar_repetidos_int(n,vec);
 x=*n;
 mostrar_vector_int(x,vec);
  }
  else
  printf("\n no hay repetidos");
  
return 0;
}

