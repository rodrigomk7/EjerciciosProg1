#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include"control_roh.h"
#include"fn_cadenas_roh.h"

int main(int argc,char *argv[])
{
int b=0,n,i,*p;
char cad[15][20];
do{
printf("\n ingrese el numero de cadenas a ingresar: ");
scanf("%d",&n);
getchar();
vcontrol_pos_int(n,p);
}while(*p!=1);

cargar_vector_cadenas(n,cad);

/*for(i=0;i<n;i++)
  { 
   printf("Ingresar una cadena: ");
   fgets(cad[i],19,stdin);
  }
*/
 for (i=0;i<n;i++)
 {  
	b=tiene_num(cad[i]);                              //strcpy(cad[i],cd[1]); //copiar cad 1 en cad2
	if(b==1)
	 fputs(cad[i], stdout);
 }
return 0;
}


