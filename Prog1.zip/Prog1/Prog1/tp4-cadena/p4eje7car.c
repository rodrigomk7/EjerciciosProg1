#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include"fn_cadenas_roh.h"
#include<stdlib.h>

int control_ope(char cad[]);


int main(int argc, char *argv[])
{
int b=1,r=0,t=0;
char cad[50]; //csim
do
{
cargar_cadena(cad);
t=control_ope(cad);
}while(t==0);


mostrar_cadena(cad);

suma_resta_cad(&b,&r,cad);

if(b==0)
printf("\n no se ingreso niguna operacion\n");
else
printf("\n resultado =  %d \n",r);
return 0;
}

/*

int control_ope(char cad[])
{
int i,b=1,bs=1;

for(i=0;i<strlen(cad);i++)
    {
		 	if(!isdigit(cad[i]) && (cad[i])!=' ' && cad[i]!='+' && cad[i]!='-' )
			{
				b=0;
			}
	}
			if(!isdigit(cad[0]) && !isdigit(cad[strlen(cad)]))
			{
				b=0;}
		
			 if(cad[i]=='+' || cad[i]=='-')
			 {
				 b=0;
			 }
     for(i=0;i<strlen(cad)&& bs==1 ;i++)
	 {
	 if(cad[i]==' ')
	    {
		 bs=0;
		   if(!(cad[i+1]=='+' || cad[i+1]=='-'))
		   {
			   b=0;
		   }
				if(!cad[i+2]==' ')
				{
				b=0;
				}
	    }
	 }
	 if(bs==1)
		 b=0;
return b;
}
*/



