#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include"control_roh.h"
#include"fn_cadenas_roh.h"

//void cargar_vector_cadenas(int, char [][20]);
//void mostrar_vector_cadenas(int, char [][20]);

int main (int argc, char *argv[])
{
int n,p=0,i=0;
char cad[15][20];
do{
printf("\n ingrese el numero de cadenas a ingresar: ");
scanf("%d",&n);
getchar();
vcontrol_pos_int(n,&p);
}while(p!=1);

cargar_vector_cadenas(n,cad);


  mayus_x_minus(cad);

mostrar_vector_cadenas(n,cad);

  return 0;
}

/*

void cargar_vector_cadenas(int n,char cad[][20])
{
int i;
for(i=0;i<n;i++)
  { 
   printf("Ingresar una cadena: ");
   fgets(cad[i],19,stdin);
  }
}

void mostrar_vector_cadenas(int n, char cad[][20])
{int i;
 for (i=0;i<n;i++)
  fputs(cad[i], stdout);
} */