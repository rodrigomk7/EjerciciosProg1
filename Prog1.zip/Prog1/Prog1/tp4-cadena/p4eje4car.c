#include<stdio.h>
#include<string.h>
#include"fn_cadenas_roh.h"

int main(int agrc, char* argv[])
{
char x, cadena[50];
int i=0;
printf("ingrese \" F\" para finalizar\n");
do
{
printf(" ingrese un caracter:");
scanf("%c",&x);
getchar();
cadena[i]=x;
i++;
}while(x!='F');
cadena[i-1]='\0';

if(strlen(cadena)==0)
    printf("\n No se ingreso ningun valor distinto de \"F\" \n ");
	else
	mostrar_cadena(cadena);
	//printf(" \n La cadena es: %s \n",cadena);
    
return 0;
}
