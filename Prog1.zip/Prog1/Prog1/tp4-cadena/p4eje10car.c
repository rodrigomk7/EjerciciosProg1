#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int eliminar_pala_repetidas(char *,char *);

int main(int argc,char *argv[])
{
int p;
char vm[50];
if(argc>3)
{
printf("\n Hay mas de 2 palabras");


p=eliminar_pala_repetidas(argv,vm);

if(p!=0)
	printf("%S", vm);
else
	printf("\n no hay repetidas\n");
}
printf("\n hay menos de dos palabras\n");
return 0;
}


int eliminar_pala_repetidas(char argv[],char vm[])
{
	int i,j,b=1; 
for(i=0;i<strlen(argv);i++)
{
	for(j=i++;j<strlen(argv);j++)
	{
     b= strcmp( argv[i],argv[j]);
	 if(b!=0)
	 {
	  strcomp(vm,argv[i]);
	 }
    }
	}
	return 0; 
	 }
