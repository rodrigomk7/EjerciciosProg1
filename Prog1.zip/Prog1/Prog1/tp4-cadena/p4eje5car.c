#include<stdio.h>

int main(int argc,char *argv[])
{
int i;
printf("\n\n");
if(argc>2)
  for(i=1;i<argc;i++)
  printf(" %s\t",argv[i]);
else
   printf("\n SE INGRESARON MENOS DE DOS PALABRAS \n\n\n");
printf("\n\n");
return 0;
}
