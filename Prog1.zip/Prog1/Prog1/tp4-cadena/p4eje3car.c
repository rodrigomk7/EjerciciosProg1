#include <stdio.h>
#include <string.h>
#include<ctype.h>
#include "fn_cadenas_roh.h"

int main (int argc, char*argv[])
{
int *b;
char cad[50], cadMay[50];
cargar_cadena(cad);
printf("\n La cadena ingresada es:");
mostrar_cadena(cad);

generar_cad_de_mayus(b,cad,cadMay);
if(*b!=0)
{
printf("\n\n La cadena modificada es:");
mostrar_cadena(cadMay);
printf("\n\n");
}
else
	printf("\n NO HAY MAYUSCULAS\n\n");
return 0;
}