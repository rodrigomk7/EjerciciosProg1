#include<stdio.h>
#include<string.h>
#include <ctype.h>
#include <stdlib.h>
#include"fn_cadenas_roh.h"

int main (int agc, char *argv[])
{
	int b,n;
	float r,x,y;
char cd1[20],cd2[20];

do
{
cargar_cadena(cd1);
b=control_float(cd1);
}while(b!=0);
printf("\n 2da cadena\n");
{
cargar_cadena(cd2);
b=control_float(cd2);
}while(b!=0);



printf("\nCadenas ingresadas:\n");
printf("%s",cd1);
printf("\n%s",cd2);

x=atof(cd1);
y=atof(cd2);


printf("\n\t\t\tElija su opcion:");
printf("\n##Suma: opcion 1\n");
printf("\n##Resta: opcion 2\n");
printf("\n##Producto: opcion 3\n");
if(y!=0)
printf("\n##Division: opcion 4\n");

printf("\nSu opcion:");
scanf("%d",&n);

r=operaciones(x,y,n);

printf("\nEl resultado es: %.2f",r);
return 0;





}