#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include"fn_cadenas_roh.h"

int main(int argc, char *argv[])
{
int i,*p;
if(argc==2)
     {
     printf("\n %s",argv[1]);

     reemplazar_min(p,argv[1]);
 
      if(*p!=0)
          printf("\n %s \n",argv[1]);
        else
          printf("\n NO hay minusculas \n");
      }
  else
     printf("\n  NO se ingreso una palabra\n");
return 0;
}

