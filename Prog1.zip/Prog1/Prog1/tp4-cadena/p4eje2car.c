
#include <stdio.h>
#include <string.h>
#include<ctype.h>
#include"fn_vectores_roh.h"
#include"fn_cadenas_roh.h"
//#include "cadenas.h"


//void gen_cadena_numeros(int,char *,char *);
//void gen_cadena_letras(int,char *,char* );


int main (int argc, char*argv[])
{
int N;
char Vcad[20],Vletra[20],Vnum[20];

do
{
printf("\n Ingrese una cantidad de caracteres:");
scanf("%d",&N);
getchar();
}while(N<=0);

cargar_vector_char(N,Vcad);
mostrar_vector_char(N,Vcad);

gen_cadena_numeros(N,Vcad,Vnum);


if(strlen(Vnum)!=0)
{
printf("\n la cadena de numeros es: \n\t");
mostrar_cadena(Vnum);
}
else
printf("\n NO hay Numeros ingresados \n");

gen_cadena_letras(N,Vcad,Vletra);

if(strlen(Vletra)!=0)
{
printf("\n la cadena de letras es: \n\t");
mostrar_cadena(Vletra);
}
else
printf("\n NO hay Letras ingresadas \n");

return 0;
}






