// sin cadena auxiliar

#include<stdio.h>
#include<string.h>
#include"fn_cadenas_roh.h"

void quita_blan(char c[]);

int main(int argc, char *argv[])
{
	char c[50],cd[50];
	cargar_cadena(c);
	//mostrar_cadena(c);
	printf("\n despues de llamar ala fn:  ");
	quita_blan(c);
	mostrar_cadena(c);
}
/*sin fn quita blancos 
sin cadena auxiliar */
void quita_blan(char c[])
{int i,k;
	for(i=0;i<(strlen(c));i++)
	{
			if(c[i]==' ')
			{
				for(k=i;k<strlen(c);)
					c[k]=c[++k];
			--i;
		    }
	}
	c[i]='\0';
}