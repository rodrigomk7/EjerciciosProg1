#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include"control_roh.h"
#include"fn_cadenas_roh.h"


int main(int argc,char *argv[])
{
int b,i,n;
int *p;
char cad[15][20];
do{
printf("\n ingrese el numero de cadenas a ingresar: ");
scanf("%d",&n);
getchar();
vcontrol_pos_int(n,p);
}while(*p!=1);

for(i=0;i<n;i++)
  { 
   printf("Ingresar una cadena: ");
   fgets(cad[i],19,stdin);
  }
orde_burbu_alf(n,cad);
mayus_primera_letra_d_ape(n,cad);
 for (i=0;i<n;i++)
 {
	 //cad[i][0] = toupper(cad[i][0]);
	
	 fputs(cad[i], stdout);
 }
return 0;
}
