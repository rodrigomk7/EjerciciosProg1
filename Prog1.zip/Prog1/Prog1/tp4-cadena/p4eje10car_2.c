#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
#include"fn_cadenas_roh.h"


int pala_repetidas(int,char cad[][20]);
void eliminar_pala_repetidas(int * ,char [][20]);
//void generar_vector_cade(int n,char arg[],char cad[][20]);



int main(int argc, char *argv[])
{
	int i,j,n,b=0,k=1,cont=0;
	char cad[15][20], cada[15][20];

	n=argc-1;
	//generar_vector_cade(n,arg,cad);
if(n>1)
{
	for(i=0;i<n;i++)
	{
		strcpy(cad[i],argv[k++]);
	}
	printf("\n la cadena ingresada es:\n");
	
	mostrar_vector_cadenas(n,cad);
	
	b=pala_repetidas(n,cad);
	
/*for(i=1;i<n;i++)
{
	j=i+1;
	for(;j<n;j++)
	{
	if(strcmp(cad[i],cad[j])==0)
	 cont++;
	}
}  */

	if(b==0)
		printf("\n no hay repe");
	else
	{
		printf("\n si hay repe \n");
		eliminar_pala_repetidas(&n,cad);
		//mostrar_vector_cadenas(n,cad);
	}
}
	else
		printf("\n se ingreso menos de dos palabras\n\n");
	return 0;
}



int pala_repetidas(int n,char cad[][20])
{
	int i,j,cont=0;
for(i=0;i<n-1;i++)
{
	j=i+1;
	for(;j<n;j++)
	{
	if(strcmp(cad[i],cad[j])==0)
	{
	 cont++;
	}
	}
}
return cont;
}



// con vector aux
void eliminar_pala_repetidas(int *n, char cad[][20])
{
int i,j,k=0;
char cada [15][20];
for(i=0;i<(*n)-1;i++)
	{
		j=i+1;
		for(;j<*n;j++)
			{
			if(strcmp(cad[i],cad[j])!=0)
				strcpy(cada[k++],cad[i]);
			}
	}
	k=k-1;
	mostrar_vector_cadenas(k,cada);
}
