#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include"fn_cadenas_roh.h"

//int gen_vector_cad(char cad[20],char vcad[][20]);


int main(int argc, char *argv[])
{
int n;
char cad[20],Vcad[20][20];

printf("\n Ingrese apellidos separados por \" ; \" :");

cargar_cadena(cad);
printf("\n\n la cadena ingresada es:\n\t");
mostrar_cadena(cad);

n=gen_vector_cad_s(cad,Vcad);
printf("\n el vect es: \n");


mostrar_vector_cadenas(n,Vcad);
return 0;
}



/*
int gen_vector_cad(char cad[20],char vcad[][20])
{
    int i,j=0,k=0;
	for(i=0;i<strlen(cad);i++)
		if(cad[i]==';')
		{
			vcad[j][k]='\0';
			j++;
			k=0;
		}
		else
		{
			vcad[j][k]=cad[i];
             k++;
	    }
vcad[j][k]='\0';
return j+1;	
}   */
  /*int i,j=0,k=0;
for(i=0;i<strlen(cad);i++)
   {
	   while(cad[j]!= ';')
	   {
		   vcad[i][k]=cad[j];
	      j++;
		  k++;
	   }
	     if(cad[i]==';');
		  {
			  vcad[j][k]='\0';
		      k=0;
			  j++;
		  
		  }
   }
   vcad[i][j]='\0';
    return j+1;
} */