#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"fn_cadenas_roh.h"


int main(int argc, char *argv[])
{
int ban=0;
if(argc==3)
      {
ban=strcmp(argv[1],argv[2]);

        if(ban>0)
        printf("\n %s - %s ",argv[1],argv[2]);
        else
          {
          if(ban==0)
          printf("\n las palabras son iguales\n");
          else
          printf("\n %s - %s  ", argv[1],argv[2] );
          }
      }
    else
        printf("\n  NO SE INGRESARON DOS PALABRAS \n\n");
 return 0;
}
