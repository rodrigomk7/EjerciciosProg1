/* p4 eje 1car - ingresar N caracteres luego contar la cantidad q sean:
numeros, ...*/

#include <stdio.h>
#include <string.h>
#include<ctype.h>
#include "fn_cadenas_roh.h"
#include"fn_vectores_roh.h"

void contar_caracteres(int N,int *,int *,int *,int *,int *,int *,char [20]);

int main (int argc, char *argv[])
{
int N,nn=0,nma=0,nmi=0,nsig=0,nesp=0,notr=0;
char Vcad[20];

do
{
printf("\n Ingrese una cantidad de caracteres:");
scanf("%d",&N);
getchar();
}while(N<=0);

cargar_vector_char(N,Vcad);
mostrar_vector_char(N,Vcad);
//cargarVectStr(N,Vcad);
//verVectStr(N,Vcad);

contar_caracteres(N,&nn,&nma,&nmi,&nsig,&nesp,&notr,Vcad);

printf("\n el numero de caracteres numericos es: %d",nn);
printf("\n el numero de letras Mayusculas es: %d",nma);
printf("\n el numero de letras Minusculas es: %d",nmi);
printf("\n el numero de Signo de Puntuacion es: %d",nsig);
printf("\n el numero de Espacios en Blanco es: %d",nesp);
printf("\n el numero de Otro tipo de caracter es: %d",notr);
return 0;
}

/*
void contar_caracteres(int N,int *nn,int *nma,int *nmi,int *nsig,int *nesp,int *notr,char Vcad[])
{
	int i;
	for(i=0;i<N;i++)
{
if(isdigit(Vcad[i]))  // devuelve !=0 si el caracter (0-9)
	{*nn=*nn+1;}
      else{
	 if(isupper(Vcad[i])) //devuelve !=0 si el caracter (A-Z)
		{*nma=*nma+1;}
                else{       
                if(islower(Vcad[i])) //devuelve !=0 si el caracter (a-z)
	               { *nmi=*nmi+1;}
			  else{
			  if(ispunct(Vcad[i])) // devuelve !=0 si el caracter
				      { *nsig=*nsig+1;}
				       else
					{
					 if(Vcad[i]==' ')
                                        	{*nesp=*nesp+1;}
                                              else
				        	  {*notr=*notr+1;}
					 }
				 }
		       }
  
}
}
} */