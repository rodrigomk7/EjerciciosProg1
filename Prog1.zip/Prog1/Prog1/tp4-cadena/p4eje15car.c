#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include"fn_cadenas_roh.h"

int main(int argc, char *argv[])
{
	int i,b=0;
	char cad[20],cada[20];
	
	cargar_cadena(cad);
	printf("\n # Antes de llamar a fn: \n\t\t\t");
	mostrar_cadena(cad);
	quita_blancos(cad,cada); 
	printf("\n\n # Despues de llamar a fn:\n\t\t\t");
	mostrar_cadena(cada);
	printf("\n\n");

return 0;
}

