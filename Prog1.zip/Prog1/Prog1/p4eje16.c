#include<stdio.h>


void cargar_matriz(int,int,int A[][50]);
void mostrar_matriz(int,int,int A[][50]);
void cargar_vect_dis_de_cero(int,int,int A[][50],int *);
void mostrar_vector(int,int*);


int main (int argc, char *argv[])
{
int m,n;
int A[50][50] , v[50];
do
{
printf("\n ingrese el num. de filas de la matriz:");
scanf("%d",&m);
}while(m<=0);
do
{
printf("\n ingrese el num. de columnas de la matriz:");
scanf("%d",&n);
}while(n<=0);

cargar_matriz(m,n,A);
printf("\n la matriz cargada es: \n");
mostrar_matriz(m,n,A);
cargar_vect_dis_de_cero(m,n,A,v);

mostrar_vector(n,v);
return 0;
}




void cargar_matriz(int m,int n,int A[][50])
{
int i,j,h=1,k=1;

for(i=0;i<m;i++)
	{
	k=1;
	for(j=0;j<n;j++)
		{
		printf("\nIngrese el elemento Mat[%d][%d]:  ",h,k++);
		scanf("%d",&A[i][j]);
		}
		h++;
	}
}
 

void mostrar_matriz(int m,int n,int A[][50])
{
int i,j;
printf("\n\n");
for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
		{
		printf("\t %d",A[i][j]);
		}
		printf("\n\n");
	}
}

void mostrar_vector(int n,int v[])
{
int i;
for(i=0;i<n;i++)
{
printf(" %d\t ", v[i]);
}
}


void cargar_vect_dis_de_cero(int m,int n,int A[][50],int v[])
{
int i,j,e=0,cont=0;

for(i=0;i<m;i++)
        {
        for(j=0;i<n;j++)
           {
                if(A[i][j]!=0)
                {
                v[e]=A[i][j];
                e++;
                }
               // else
                //cont++;
           }
       }
        //if(cont==(m*n))
        //printf("\n todos los elementos son iguales a 0");
        //else
        mostrar_vector(e,v);
  }


