#include <stdio.h>
int main (int argc, char *argv[])
{
int n=1000,inv=0,aux;
/*do
{
printf("\n ingresar un numero al que se invertira:");
scanf("%d",&n);
}*/
aux=n;
while((n<999)||(n>10000))
{
	while (aux!=0)
	{
         inv=inv*10+aux%10;
        aux=aux/10;
	}

       if(n==inv)
      {
          printf("\n %d",inv);
      }
      
aux++;
    }

return 0;
}