/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1 
	
	Ejemplo N� 12
	Estructura while (...) { ... }
	
*/

#include <stdio.h>

int main(int argc, char *argv[])
{
	int 	cantidad, contador = -4;
	
 	
	printf("\n Ingrese cantidad de iteraciones: ");
	scanf("%d", &cantidad);
	
	printf("\n");
	
	while(contador <= cantidad)
	{
		printf("%+5d ", contador);
		contador ++; 
	}
	
printf("\n\n");
return 0;
}
