/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1 
	
	Ejemplo N� 8
	Funci�n scanf(..)
*/

#include <stdio.h>

int main(int argc, char *argv[])
{
	
	char 	car = 'x'; 		
	int 	cont_1 = 12; 	
	float 	e = 2.71828;
		
	printf("\n Ingrese un caracter: ");
	scanf("%c", &car);
	printf(" El caracter es: %c", car);
	
	 fgetc(stdin);
	
	printf("\n Ingrese un caracter: ");
	scanf("%c", &car);
	printf(" El caracter es: %c", car); 
	
	printf("\n\n Ingrese un entero: ");	
	scanf("%d", &cont_1);	
	printf("El valor entero es: %d", cont_1);
	
	printf("\n\n Ingrese un entero: ");
	scanf("%d", &cont_1);
	printf(" El valor entero es: %d", cont_1);
	
	printf("\n\n Ingrese un real: ");
	scanf("%f", &e);
	printf("El valor punto flotante es: %f", e);
	
printf("\n\n");		
return 0;
}
