/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1 
	
	Ejemplo N� 16
	Punteros
	
*/

#include <stdio.h>

int main(int argc, char *argv[])
{
	int 	ent, *ptri;
	float	real, *ptrf;
	char	car, *ptrc;
	
	ptri = &ent;  
	//a ptri se asigna la direcci�n de ent
	
	*ptri = 25; 
	//por indirecci�n se asigna a ent el valor 25

	//ptrf = &ent;  
	// INSTRUCCI�N INV�LIDA, ptrf debe apuntar a un float y se le asigna direcci�n de int
	
	real = 93.732;
	ptrf = &real;
	
	
	printf("\n Valores enteros: %d      %d ",  ent , *ptri);
	printf("\n Direcciones de los valores enteros: %p   %p", &ent, ptri);
	
	printf("\n\n Valores reales: %5.4f  %3.4f ",  real , *ptrf);
	printf("\n Direcciones de valores los reales: %p   %p ", &real, ptrf);
		
printf("\n\n");
return 0;
}
