/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1 
	
	Ejemplo N� 7
	Formato de salida de datos
*/

#include <stdio.h>

int main(int argc, char *argv[])
{
	
	char 	car = 'r'; 		
	int 	cont_1 = 17; 	
	float 	e = 2.71828;
		
	printf("\n El caracter es: %c **", car);
	printf("\n El caracter es: %10c **", car); 
	printf("\n El caracter es: %-10c **", car);
	printf("\n El caracter es: %+10c **", car); 
	printf("\n El caracter es: %010c **", car);
	
	printf("\n\n El valor entero es: %d", cont_1);
	printf("\n El valor entero es: %10d", cont_1);
	printf("\n El valor entero es: %-10d", cont_1);
	printf("\n El valor entero es: %+10d", cont_1);
	printf("\n El valor entero es: %010d", cont_1);
	
	printf("\n\n El valor punto flotante es: %f", e);
	printf("\n El valor punto flotante es: %10.5f  **", e);
	printf("\n El valor punto flotante es: %-10.5f  **", e);
	printf("\n El valor punto flotante es: %+10.5f  **", e);
	printf("\n El valor punto flotante es: %+10.5f  **", (-1)*e);
	printf("\n El valor punto flotante es: %0.1f", e);
	printf("\n El valor punto flotante es: %10.5f", e);
	printf("\n El valor punto flotante es: %0.1f", e);
	printf("\n El valor punto flotante es: %010.5f", e);
	
printf("\n\n");
return 0;
}
