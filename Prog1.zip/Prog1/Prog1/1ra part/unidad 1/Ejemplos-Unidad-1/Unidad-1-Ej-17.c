/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1 
	
	Ejemplo N� 17
	Incremento de punteros
*/

#include <stdio.h>

int main(int argc, char *argv[])
{
	short int 	ent , *ptri;
	float	real, *ptrf;
	char	car, *ptrc;
	
	//ptri = ent;
	ptri = &ent;  
	ptrf = &real; 
	ptrc = &car;
	printf("\n Direcciones:            %10p %10p %10p", ptri, ptrf, ptrc);
	// Incremento de punteros	
	ptri++;
	ptrf++;
	ptrc++;
	printf("\n Luego del incremento:   %10p %10p %10p", ptri, ptrf, ptrc);
	
printf("\n\n");
return 0;
}
