/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1 
	
	Ejemplo N� 10
	Estructura if( ) .... else ....
*/

#include <stdio.h>

int main(int argc, char *argv[])
{
	
	char 	car = 'x'; 		
	int 	cont_1 = 12, suma = 0;
 	float 	e = 2.71828;
		
	if (car == 'x')
		printf("\n\n El caracter es: %c", car);
	else
		printf("\n\n El caracter es distinto que %c", car);
	
	if (car == 'p')
	{
		printf("\n\n El caracter es: ");
		printf(" %c",'p');
	}
	else
		printf("\n\n El caracter es distinto que %c", car);
	
	if (cont_1)
		printf("\n\n %d es distinto que 0", cont_1);
	else
	{
		printf("\n\n");
		printf("%d es igual que 0", cont_1);
	}
	
	if (suma)
		printf("\n\n %d es distinto que 0", suma);
	else
		printf("\n\n %d es igual que 0", suma);
	
	if (e == 2.71828)
		printf("\n\n e es igual que %f", e);
	else
		printf("\n\n e es distinto que %f ???", e);

printf("\n\n");	
return 0;
}
