/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1 
	
	Ejemplo N� 3
	Declaraci�n de constantes - Asignaci�n
*/
#include <stdio.h>

int main(int argc, char *argv[])
{
	
	const 	int   	DIAS = 12; 
	const 	float 	R = 0.082;
	
	char 	car; 		
	int 	cont_1, suma = 0; 	
	float 	promedio; 
		
	car =  'r';
	cont_1 =  16;
	promedio  =  cont_1 / 5;
	
	 DIAS = 30;

return 0;
}
