/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1 
	
	Ejemplo N� 6
	Funci�n printf()
	Secuencias de escape
	Especificador de tipo de datos    
*/
#include <stdio.h>

int main(int argc, char *argv[])
{
	
	char 	car = 'r'; 		
	int 	cont_1 = 16; 	
	float 	e = 2.71828;
	float 	promedio = (float)cont_1/7;
	
	printf(" Este es un mensaje");
	printf(" para la clase de Programacion I");
		
	printf("\n\n El caracter es: %c ", car);    
	printf("\n El caracter es: %d", car); 
	printf("\n El caracter es: %f", car);
	
	printf("\n\n El valor entero es: %i", cont_1);
	printf("\n El valor entero es: %d", cont_1);
	printf("\n El valor entero es: %c", cont_1);
	printf("\n El valor entero es: %f", cont_1);
	
	printf("\n\n El valor punto flotante es: %f", e);
	printf("\n El valor punto flotante es: %d", e);
	printf("\n El punto flotante es: %c", e);
	
	printf("\n\n El valor de promedio es: %f", promedio);

return 0;
}
