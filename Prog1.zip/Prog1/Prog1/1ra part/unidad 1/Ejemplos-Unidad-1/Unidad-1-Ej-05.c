/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1 
	
	Ejemplo N� 5
	Operador condicional
*/

#include <stdio.h>

int main(int argc, char *argv[])
{
	
	char 	car = 'x'; 		
	int 	cont_1 = 12, suma = 0;
		
	car = 'y' ? printf("\n\n El caracter es: %c", car) :
			printf("\n\n El caracter es distinto que %c", car);
	
	cont_1 ? 	printf("\n\n %d es distinto que 0", cont_1) :
		printf("\n\n %d es igual que 0", cont_1);
		
	suma ? 	printf("\n\n %d es distinto que 0", suma) :
		printf("\n\n %d es igual que 0", suma);
printf("\n\n");
return 0;
}
