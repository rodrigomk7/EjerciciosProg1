/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 1 
	
	Ejemplo N� 1
	Estructura de un programa en lenguaje C
*/

// Directivas al compilador

#include <stdio.h>

// Declaraciones globales: Funciones

int main(int argc, char *argv[])
{
	
	// Declaraciones de variables
	
	 //Sentencias
	
return 0;
}

// Definici�n de funciones
