#include<stdio.h>

int control(int a);
float potencia(float , int );


int main (int argc, char *argv[])
{
	int e,ban;
	float n,pot;
	do
	{
		ban=0;
		printf ("\n ingresar la base:");
		scanf("%f",&n);
		ban=control(n);
	}while(ban==0);
	do
		{ 
		ban=0;
		printf ("\n ingresar la exp: ");
		scanf("%d",&e);
		ban=control(e);
	}while(ban==0);
	
	pot=potencia(n, e);
	 
	 printf ("\n la potencia es:  %5.3f",pot);
	  return 0;
}




int control(int x )
{ 
int k;
	if (x>0)
      k=7;
	return (k);
}



float potencia(float t, int y)
{
	int cont=1;
	float pot=1;
	
	while (cont<=y)
	{
		pot=pot*t;
		cont++;
	}
	return (pot);
}
	