// tp3- eje 10- binaniro a decimal con funciones
#include <stdio.h>
 
int controlbin(int bin); 
int binadec(int bin);
 
int main(int argc, char *argv[])

{
int bin,dec,ban=0;

printf("\n\n    \"PROG. Para Pasar De BINARIO A DECIMAL\" \n\n");

do
{
printf("\n Ingresar un numero binario:");
scanf("%d",&bin);
ban=controlbin(bin);
}while(ban==0);
 dec= binadec(bin);
 printf("\n El numero binario %d es equivalente a %d en decimal \n\n",bin,dec);
 return 0;
}

//sub prog para control de numero binario
int controlbin(n) 
{
int aux,c,ban;

aux=n;
c=0; if(aux>0)
       {
        while(aux!=0)
        {
                if(aux%10>2)
                {
                c=c+1;
                }
          aux=aux/10;
        }

        if(c==0)
        {
          ban=7;
        }
        else
        {
           ban=0;
        }
      }
      else
      ban=0;  
return (ban);
}

// subprog para pasar de binario a decimal

int binadec(bin)
{ int b,pot,r,dec;

b=bin;
pot=1;
dec=0;
while(b>0)
{
r=b%10;
dec=dec+r*pot;
pot=pot*2;
b=b/10;
}
return (dec);
}
