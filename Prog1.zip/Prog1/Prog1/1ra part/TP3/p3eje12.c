#include<stdio.h>


int control(int x);

int controlb(int s);

int convertir_a_b(int y, int z);


int main (int argc,char *argv [])
{
int n,b,ban,con;

printf("\n\n\n \"Prog. Para Convertir A Cualquier Base\"\n\n\n");

do
{
ban=0;75
printf("\n ingresar un numero:");
scanf("%d",&n);
ban=control(n);
}while(ban==0);
do
{
ban=0;
printf("\n ingresar un base:");
scanf("%d",&b);
ban=controlb(b);
}while(ban==0);

con=convertir_a_b(n,b);

printf("\n la conversion de \"%d\" a base \" %d \" es \"%d\" \n\n\n",n,b,con);
return 0;
}




int control(int x)
{ int ban;
if(x<0)
ban=0;
else
ban=7;
return ban;
}





int controlb(int s)
{ int ban;
if(s>1&&s<10)
ban=7;
else
ban=0;
return ban;
}



int convertir_a_b(int y,int z)
{
int r, aux,pot=1,bin=0;
aux=y;
while(aux!=0)
{
r=aux%z;
bin=bin+r*pot;
pot=pot*10;
aux=aux/z;
}
return bin;
}