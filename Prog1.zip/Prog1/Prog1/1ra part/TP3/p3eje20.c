// p3 -eje 20

#include<stdio.h>

void bus_may_pos(int, int *, int* );

int main ( int argc, char * argv [])
{
int n, my, pm;

printf ("\n Prog. para buscar el mayor valor ingresado y su posicion \n\n");

do
{
printf("\n ingrese una cantidad de numeros:  ");
scanf("%d",&n);
}while(n<0);

bus_may_pos(n,&my,&pm);

 if(pm>n)
 printf("\n Todos los numeros son iguales");
else
printf("\n el mayor valor ingresado es %d e ingresa en la posicion %d ",my,pm);
return 0;
}


void bus_may_pos(int n, int *my, int *pm )
{
int x, cont=1,i=1;
while(cont<=n)
    {
        printf("\n ingresa un valor:");
        scanf("%d",&x);
                if(cont!=1)
                {
                        if(x <= *my)
                        {
                                      if(x==*my)
                                                 i++;
                         }
                      else
                      {
                      *my=x;
                      *pm=cont;
                      }
               }
               else
               {
               *my=x;
               *pm=cont;
               }
    cont++;
    }
    
    if(i==n)
    *pm=n+2;
    }
               
