// tp3- eje9 calcular resto de divicion entera usando funciones

#include <stdio.h> 

int control (int a);

int div (int a, int b);

int main (int argc, char *argv[])

{
 int n,d,ban,cociente;

printf("\n\n  \"Prog. Para Calcular El Resto De La Divicion Entera\" \n\n");

 do
 {
 printf("\n Ingresar el numerador:");
 scanf("%d",&n);
ban=control(n);
 }while(ban==0);

 do{
 printf("\n Ingresar el denominador:");
 scanf("%d",&d);
 ban=control(d);
 }while(ban==0);

 cociente=div(n,d);
 printf("\n El resto de la divcion entera es:%d \n\n",cociente);
return 0;
}

int control (x)
{ int ban;
if(x>0)

ban=7;
else
ban=0;
return (ban);
}


int div (r, d)
{
int c;
 while(r>=d)
        {
        r=r-d;
        c=c+1;
        }
        return (r);
        }



 
