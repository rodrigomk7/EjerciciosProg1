// p3 - eje 6


#include<stdio.h>


int main (int argc, char *argv [])
{
int n, d, x=2, cont, s=0, *p2, *p1;
do
{
printf("\n ingrese una cantidad de numeros:");
scanf ("%d",&n);
}while(n<=0);

p1=&n;

while(x <= *p1)
        {
        cont=0;
         d=2;         
           while(x>d)
                    {
                                   if(x%d==0)
                                   {
                                      cont++;
                                    }
                     d++;
                    }
                    
                    if(cont==0 )
                     {
                       s=s+x;
                       }
          x++;
          }
          
          p2=&s;
          
       
printf(" la suma de los primos menores que %d es: %d  \n", *p1, *p2);
       
       
return 0;
}

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
