//tp3- eje11- invertir un numero de dos o mas digitos

#include<stdio.h>


int control(int x);
int invertir(int x);

int main(int argc, char *argv[])
{
int n,aux1,ban,inverso;

printf ("\n\n\n\n\"Prog. Para Ivertir Un Numero De Dos O Mas Digitos\"   \n\n\n");

do
{
printf("\n Ingresar un numero:");
scanf("%d",&n);
aux1=n;

ban=control(aux1);

}while(ban==0);

inverso=invertir(aux1);

printf("\n El numero ingresado es: %d\n",n);
printf("\n Y su inverso es: %d \n\n\n\n",inverso);
return 0;
}




int control(x)
{ int ban;
if(x>10)
      ban=7;
      else
      ban=0;

 return (ban);
 }
 


int invertir(x)
{
int aux,inv=0;
aux=x;
while(aux>0)
{
               inv=inv*10+aux%10;
               aux=aux/10;

}
return (inv);
}

