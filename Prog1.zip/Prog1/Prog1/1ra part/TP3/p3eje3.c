// tp3- eje 3-

#include <stdio.h>

int suma(int x, int y);
int dif(int x, int y);

int main (int argc, char *argv[])
{
int re,rr,im,img,sr=0,si=0,dr=0,di=0;
printf("\n\n    \" PROG. PARA SUMAR NUMEROS COMPLEJOS    \"   \n\n\n ");
printf("\n ingresar componente real del 1mr numero:");
scanf("%d",&re);
printf("\n ingresar componente img del 1mr numero:");
scanf("%d",&im);
printf("\n ingresar componente real del 2do numero:");
scanf("%d",&rr);
printf("\n ingresar componente img del 2do numero:");
scanf("%d",&img);

      sr=suma(re,rr);
      si=suma(im,img);
      dr=dif(re,rr);
      di=dif(im,img);

  printf("\n\n\n la suma de los numeros complejos es:(%d ,%d)",sr,si);
  printf("\n y en forma binomica es: %d + %di \n\n\n",sr,si);
  printf("\n la dif de los numeros complejos es:(%d ,%d)",dr,di);
  printf("\n y en forma binomica es: %d + %di \n\n\n",dr,di);
  return 0;
  }


  int suma (x,y)
  {
 return(x+y);
  }

  int dif (x,y)
  {
   return(x-y);
  }
