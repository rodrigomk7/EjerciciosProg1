

#include<stdio.h>

void letras();


int main (int argc, char *argv [])
{
    int n, c=0;
    
   printf ("\n  Prog. Para Mostrar N Letras Mayusculas\"   "); 
    
    do 
    {
        printf ("\n\n\n  ingresa una cantidad de letras:   ");
        scanf("%d",&n);
        
             printf(" \n ");
             
        
    }while (n<=0);
    
    while (c<n)
    {
        letras();
        c++;
    }
    return 0;
}
 
 
 void letras()
 {
     static char letra= 'A';
     

     
     printf (" - %c ", letra);
     
     letra++;
 }