#include <stdio.h>

int control_letra(char );
void ordenar(char, char);


int main (int argc, char *argv [])
{

int ban;
char  a,b;

printf("\n\n     \"Prog. Para Ordenar Pares De Letras\"        \n\n");

do 
{
ban=0;
printf("\n ingresar un letra:");
scanf("%c",&a);
ban=control_letra(a);
}while (ban=0);
getchar();
do 
{
ban=0;
printf("\n ingresar otra letra:");
scanf("%c",&b);
ban=control_letra(b);
}while(ban==0);

ordenar(a,b);
}


int control_letra ( char x)
{ 
if (x>= 'a' && x<='z')
{return 7;
}
else
{
return 0;
}
}


void ordenar (char x, char y)
{
if(x<y)
{
        printf( "\n su orden es: %c - %c",x,y );
}
else
 {
        if(x>y)
        {
               printf( "\n su orden es: %c - %c", y,x);
        }
        else
        {
               printf(" \n las letras son iguales");
        }
 }
}
