// p3 -eje 21

#include<stdio.h>

void suma (int, int, int * );
void resta(int, int, int *);


int main ( int argc, char * argv [])
{
int r1, r2, i1, i2, rsr, rsi, rrr,rri;

printf ("\n Prog. para sumar y restar complejos \n\n");


printf("\n ingresa la parte real de el 1° complejo:  ");
scanf("%d",&r1);
printf("\n ingresa la parte img de el 1° complejo:  ");
scanf("%d",&i1);
printf("\n ingresa la parte real de el 2° complejo:  ");
scanf("%d",&r2);
printf("\n ingresa la parte img de el 2° complejo:  ");
scanf("%d",&i2);

suma (r1,r2, &rsr);
suma(i1,i2,&rsi);
resta(r1,r2,&rrr);
resta(i1,i2,&rri);

printf("\n el resulatado de la suma es %d + (%d)i ", rsr, rsi);
printf("\n el resulatado de la diferencia es %d + (%d)i ", rrr, rri);

return 0;
}


void suma(int a, int b, int *r)
{
*r=a+b;
}

void resta (int a, int b, int *r)
{
*r=a-b;
}

