// p3- eje7 

#include<stdio.h>

int main (int argc, char *argv [])
{
int n, *domicilio, *valor, *dom_puntero;

printf("\n ingrese un numero entero:");
scanf("%d",&n);


valor=&n;

//dom_puntero=&valor;

domicilio=&n;

printf("\n el valor ingresado es: %d", *valor);
printf("\n el domicilio del valor es: %d", &valor);
printf("\n el domicilio de momeria del puntero es: %d", &dom_puntero);

return 0;
}
