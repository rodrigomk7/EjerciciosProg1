// p3- eje 17

#include <stdio.h>


int suma_impares(int);
int es_impar(int );


int main (int argc, char *argv[])
{
int n,suma=0;
do 
{
printf(" \n ingresa un valor:");
scanf("%d",&n);
}while(n<=0);

suma=suma_impares(n);

if(suma==0)
{
printf( "\n NO se ingresaron valores impares");
}
else
{
printf("\n la suma de los num imp es: %d",suma);
}
return 0;
}




int suma_impares(int num)
{
int cont=1, x=1, s=0, ban;


while(cont<=num);
{

    ban=es_impar(x);

        if(ban==7)
             {
              s=s+x;
             }
        
  cont++;
  x++;
}

return s;
}



int es_impar (int x)
{
if(x%2!=0)
{
return 7;
}
else
{
return 0;
}
}

