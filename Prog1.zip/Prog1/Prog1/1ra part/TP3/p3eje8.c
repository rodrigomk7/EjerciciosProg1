// tp3- eje8 calcular potencia usando funciones

#include <stdio.h> 

int contrlpos (int e,int f);

int pot (int bas,int exp);

int main (int argc, char *argv[])

{
 int a,b,ban=0,mul;
 
 printf("\n\n   \"Prog. Para Calcular Potencias\"   \n\n");

  do{
  
   printf ("\n   Ingresar el valor de la base:");
   scanf ("%d",&a);
   printf ("\n   Ingresar el valor del exponente:");
   scanf ("%d",&b);

    ban=contrlpos(a,b);
    
    }while(ban=0);
    
    mul=pot(a,b);
    printf("\n El resultado de la potencia es:%d",mul);
    return 0;
}


// control positivo

  int contrlpos(e,f)
{
int ban;
if(e>0&&f>0)
        ban=7;
 return (ban);
 }

// calculo la pot

  
int pot (x,y)
{
int s=0,c=0;
while(c<y)
{
s=s+x;
c++;
}
return (s);
}
