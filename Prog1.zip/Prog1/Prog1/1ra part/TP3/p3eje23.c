
// p3 - eje 23-

#include<stdio.h>

void sumar_primos(int, int );
void es_primo(int, int*);

int main ( int argc, char *argv [])
{
   int n1,n2;
printf("\n ingresar un numero:");
scanf("%d",&n1);
printf("\n ingresar otro valor:");
scanf("%d",&n2);

sumar_primos(n1,n2);

return 0;
}

void sumar_primos(int a,int b)
{
int x=a+1,sp=0,ban;

while(a<x&&x<b)
{
es_primo(x,&ban);

if(ban==7)
{
sp=sp+x;
}
x++;
}

printf ("\n la suma de los numeros primos entre %d y %d es %d",a,b,sp);
}



void es_primo(int p,int *s)
{
     int d=2,c=0;

while (p>d)
{
        if(p%d==0)
        {
        c++;
        }
   d++;
 }
if (c==0)
*s=7;
else
*s=0;
}   
 
