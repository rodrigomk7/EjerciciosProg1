// numeros triangulares


#include<stdio.h>

void serie_fibo();

int main(int argc, char *argv [])
{
int n, cont=0;
do
{
printf("\n ingresa una cantidad:");
scanf("%d",&n);
}while(n<=0);

while(cont<n)
{
serie_fibo();

cont++;
}
return 0;
}



void serie_fibo()
{
static int x=0,y=1;
int aux;
printf("--  %d ",x);
aux=x;
x=aux+y;
y=aux;

}
