//p3_ eje27


#include<stdio.h>

void serie_impares(int, int *);

int main (int argc, char *argv [])
{
int n,c=1,x,cs=0;
do 
{
printf("\n ingresa un numero:");
scanf("%d",&n);
}while(n<=0);

while(c<=n)
{
printf("\n ingresa un valor:");
scanf("%d",&x);


serie_impares(x,&cs);
c++;
}
printf("\n la cantidad de series %d ", cs);

return 0;
}


void serie_impares(int x,int *cs)
{

 static int cp=0;

if(x%2!=0)
cp++;
else
cp=0;

if(cp==2)
*cs=*cs+1;
}




