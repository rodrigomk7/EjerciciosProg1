
#include<stdio.h>

void control_pos(int, int*);
void control_base(int, int*);
void conversion(int,int, int*);

int main (int argc, char *argv[])
{
int conv, ba,N,B;

do
{
printf("\n ingresa un numero:");
scanf("%d",&N);
control_pos(N,&ba);
}while(ba==0);

do
{
ba=0;
printf("ingresa la base:");
scanf("%d",&B);
control_base(B,&ba);
}while(ba==0);

conversion(N,B,&conv);

printf("\n la conversion de %d a %d es %d ",N,B,conv);
return 0;
}


void control_pos(int x, int *b)
{
if(x<0)
*b=0;
else
*b=7;
}


void control_base(int x, int *b)
{
if(1<x && x<11)
*b=7;
else
*b=0;
}


void conversion(int a, int b, int *cv)
{
int r, aux,pot=1;


*cv=0;
aux=a;

while(aux!=0)

{

r=aux%b;

*cv = *cv +(r*pot);

pot=pot*10;
aux=aux/b;
}


printf("\n %d  \n",*cv);

}


