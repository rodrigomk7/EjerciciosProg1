//p3 - eje 14
 #include<stdio.h>

int suma_primo_menor_q_n(int);
void es_primo(int, int *);

 int main (int argc, char *argv [])
 {
 int n, suma;
 do
 {
 printf("\n ingresa un numero:");
 scanf("%d",&n);
 }while(n<=0);

 suma = suma_primo_menor_q_n(n);

printf("\n la suma de los numeros primos menores q %d es %d",n,suma);

return 0;
}


int suma_primo_menor_q_n(n)
{
int x=1,c=1,s=0,ban;


while (c<=n)
  {

     es_primo(x,&ban);

        if(ban==7)
                {
                s=s+x;
                }
    x++;
    c++;
}
return (s);
}



void es_primo(int e, int *ba)
{

int d=2,co=0;

if(e > d)
 {
        if(e%d==0)
        co++;
 d++;
 }

 if(co==0)
 *ba=7;
 else
 *ba=0;
}






