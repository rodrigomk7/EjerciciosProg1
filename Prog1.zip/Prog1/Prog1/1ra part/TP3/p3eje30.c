// numeros triangulares


#include<stdio.h>

void triangulares();

int main(int argc, char *argv [])
{
int n, cont=0;
do
{
printf("\n ingresa una cantidad:");
scanf("%d",&n);
}while(n<=0);

while(cont<n)
{
triangulares();

cont++;
}
return 0;
}



void triangulares()
{
static int x=1,y=2;

printf("-   %d ",x);

x=x+y;
y++;

}
