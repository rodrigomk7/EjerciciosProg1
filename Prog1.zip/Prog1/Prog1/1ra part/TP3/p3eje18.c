#include<stdio.h>

void menor_impar(int);

int main (int argc, char *argv[])
{
int g;

do
{ 
printf("\n Ingresar la cantidad del conjunto de numeros:");
scanf("%d",&g);
}while(g<0);

menor_impar(g);

return 0;
}





void menor_impar(int n)
{
int x,cont=1,ban=1,men,i=1;

	while(cont<=n)
	{
	printf("\n Ingresar un valor del conjunto:" );
	scanf("%d",&x);
           if(x%2!=0)
		{
			if(ban!=1)
			{
			     if(x<men)
				{
				men=x;
				}
			}
			else
			{
			men=x;
			ban=7;
			}
                  }
		  else
		  {
		  i++;
                  }
         cont++;
         }
if(cont!=i)
	{
	printf("\n El menor numero impar ingresado es:%d  \n",men);
	}
	else
	{
	printf("\n \"No se ingresaron valores impares\" \n\n\n");
	}
	}
