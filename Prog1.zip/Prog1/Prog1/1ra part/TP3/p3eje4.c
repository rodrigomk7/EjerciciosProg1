#include <stdio.h>
 
//int duplicar (int x);
 
int main (int argc, char *argv[])

{

int n,doble;

printf("\n\n    \"PROG. Para Duplicar un numero\" \n\n");

printf("\n Ingresar un numero a duplicar:");
scanf("%d",&n);

//doble=duplicar(n);
doble=n+n;

printf("\n el doble de %d es:%d" ,&n, &doble);
return 0;
}

/*int duplicar(x)
{
 int dob;
dob x+x;
return (x);
} */
 
