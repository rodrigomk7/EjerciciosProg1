#include <stdio.h>

int control1(int);
int control2(int);
int convdab(int, int);

int main(int argc, char *argv[])
{
int n,b,conv;

printf("Ingrese un numero entero positivo:");
scanf("%d",&n);
n=control1(n);

printf("Ingrese la base a convertir:");
scanf("%d",&b);

b=control2(b);

conv=convdab(n,b);
printf("\n %d en base %d es: %d \n",n,b,conv);

return 0;
} 

int control1(int a)
{
while(a<0)
{
printf("\n ¡Error!: se ingreso un numero negativo.");
printf("\n Ingrese un numero entero positivo:");
scanf("%d",&a);
}
return a;
}

int control2(int b)
{
while(b<=1||b>=10)
{
printf("\n ¡Error!:La base debe ser mayor que 1 y menor que 10");
printf("\n Ingrese la base a convertir:");
scanf("%d",&b);
}
return b;
}

int convdab(int n,int b)
{
int aux,p=1,cv=0;
aux=n;
while(aux>0)
{
cv=cv+(aux%b)*p;
p=p*10;
aux=aux/b;
} 
return cv;
}




