// p3- eje 19 

#include<stdio.h>

void control(int, int, int*);
void suma_pr(int, int);
void es_primo(int, int *);


int main (int argc, char *argv [])
{
int n1,n2,ba;

 printf ("\n\n \"Prog. Para Sumar Numeros Primos Entre Dos Numeros\"  \n\n");

do
{
do
{
printf("\n ingrese un numero:");
scanf("%d",&n1);
}while(n1<0);
do
{
printf("\n ingrese otro numero:");
scanf("%d",&n2);
}while(n2<0);

control (n1,n2,&ba);

}while (ba==0);

suma_pr(n1,n2);

return 0;
}



void control(int a, int b, int *ba)
{
if(a<b)
*ba=7;
else
*ba=0;
}


void suma_pr(int a, int b)
{
int x=a+1,sp=0,ban=0;

while (a<x && x<b)
{

es_primo(x,&ban);

                if(ban==7)
                {
                        sp=sp+x;
                 }
x++;
}



if(sp!=0)
printf("\n la suma de numeros primos entre %d y %d es = %d",a, b, sp);
else
printf("\n NO existen numeros primos entre %d y %d \n", a,b);
}

void es_primo(int p, int *b)
{
int d=2,cont=0;

while(p>d)
{
        if(p%d==0)
        {
        cont++;
        }
  d++;
  }
  if(cont==0)
  {
  *b=7;
 }
  else
  {
  *b=0;
 }
 }

