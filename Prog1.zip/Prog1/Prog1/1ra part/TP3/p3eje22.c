// p3 -eje 22

#include<stdio.h>

void control (int,int * );
void potencia (float, int);


int main ( int argc, char * argv [])
{
int e,h=0;
float b;
printf ("\n Prog. para calcular potencia \n\n");

printf ("\n ingrese la base: ");
scanf("%f",&b);
do
{
printf ("\n ingrese el exponente:");
scanf("%d",&e);
control(e, &h);
}while (h==0);

potencia(b,e);

return 0;
}

void control(int a, int *r)
{
if(a<0)
*r=0;
else
*r=7;
}

void potencia(float a, int b)
{
float pot=1;
int cont=1;
while(cont<=b)
{
pot=pot*a;
cont ++;
}
printf("\n el resultado de la potencia es: %10.6f", pot);
}





