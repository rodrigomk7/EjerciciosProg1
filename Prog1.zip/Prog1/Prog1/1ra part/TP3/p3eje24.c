// p3 -eje 24

#include<stdio.h>

void control (int,int * );
void fact (int);


int main ( int argc, char * argv [])
{
int a, ban;
do
{
printf ("\n ingrese un numero:");
scanf("%d",&a);
control( a, &ban);
}while(ban==0);

fact(a);

return 0;
}

void control(int x, int *b)
{
if(x<0)
*b=0;
else
*b=7;
}

void fact(int a)
{
int cont=1, fac=1,b=1;
while (cont<=a)
{
fac=fac*b;
b++;
cont++;
}
printf("\n el factorial de %d es %d",a , fac);
}



