 //tp3- eje13 - control primo de un num entero positivo

#include<stdio.h>


int control(int x);
int esprimo(int x);

int main(int argc, char *argv[])
{
int n,aux,ban,rmk;

printf ("\n\n\n\n\"Prog. Para Saber Si Un Numero Entero Positivo  Es Un Numero Primo\"   \n\n\n");
do
{
printf("\n Ingresar un nunero:");
scanf("%d",&n);
ban=control(n);
}while(ban==0);

rmk=esprimo(n);

if(rmk!=1)
printf("\n el numero %d es primo  \n\n\n",n);
else
printf("\n El numero %d NO es primo \n\n\n",n);

return 0;
}


int control(x)
{
int ban;

if(x>0)
ban=7;
else
ban=0;
return(ban);
}



int esprimo(x)
{
int d=2,cont=0,i;
   while(x>d)
   {
        if(x%d==0)
        {
        cont++;
        }
    d++;
   }
        if(cont==0)
        {
        i=2;
        }
        else
        {
        i=1;
        }
        return (i);
}
