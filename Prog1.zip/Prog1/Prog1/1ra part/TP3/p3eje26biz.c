// p3 -eje 26

#include<stdio.h>

void control_pos (int , int * );
void promedio_primos (int,int *,float *);
void es_primo (int , int *);



int main ( int argc, char *argv [])
{
int  n,x,b,cont=1, ban;
float pp;
do
{
printf("\n ingrese una cantidad de numeros:");
scanf("%d",&n);
control_pos(n,&b);
}while(b==0);

promedio_primos(n,&ban,&pp);



if (ban==7)
printf("\n el promedio de los num prim es %f",pp);
else
printf ("\n NO se ingresaron numeros primos");

return 0;
}

// control pos

void control_pos(int e, int *i)
{
if(e>0)
*i=7;
else
*i=0;
}

// promedio




void promedio_primos(int n, int *band, float *pp)
{
int ba,b,x, sp=0, cp=0, np=0,cont=0;

while (cont<n)
{
do
{
b=0;
printf("\n ingrese un valor:");
scanf("%d",&x);
control_pos(x,&b);
}while(b==0);


    es_primo (x,&ba);

                 if (ba!=7)
                                 {
                                 np++;
                                 }
                          else
                                {
                                 sp=sp+x;
                                  cp++;
                                 }
    cont++;
}                             
        
     if(np!=cont)
          {
                        if (cp!=0)
                                            {
                                             *band=7;
                                             *pp=sp/cp;
                                             }            
          }
      else
                       {
                       *band=0;
                       }
                       
}




// es primo

void es_primo(int x,int *ban)
{
     int d=2,c=0;

while (x>d)
{
        if(x%d==0)
        {
        c++;
        }
   d++;
 }
if (c==0)
*ban=7;
else
*ban=0;
}      
