#include<stdio.h>

void control_pos(int, int *);

void div_rest(int x,int y);

int main(int argc, char* argv[])
{
int n,d, ban;

printf ("\n\n prog. para dividir enteros          \n\n");
do
{ 
printf(" ingresar el numerador:");
scanf("%d",&n);
control_pos(n,&ban);
}while(ban==0);

do
{
printf("\n ingrese el denominador:");
scanf("%d",&d);
control_pos(d,&ban);
}while(ban==0);

div_rest(n,d);

return 0;
}


void control_pos(int a, int *b)
{
if(a<0)
*b=0;
else
*b=7;
}


void div_rest(int x,int y)
{
int res=x,coc=0,cont=0;
while (x>=y)
{
x=x-y;
coc++;
}
printf (" \n cociente = %d \n resto = %d",coc,x);
}

