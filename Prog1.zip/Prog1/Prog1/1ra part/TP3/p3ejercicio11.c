#include <stdio.h>
int control(int);
int invertido(int ,int);
int invertido(int,int);
int main (int argc, char *argv[])
{
int x,inv;
printf("Ingrese un numero entero:");
scanf("%d",&x);
x=control(x);
inv=invertido(x,inv);

printf("El invertido de %d es: %d",x,inv);

return 0; 
}


int control(int x)
{
while(x<10)
{
printf("Ingrese un numero entero:");
scanf("%d",&x);
}
return x;
}

int invertido(int x,int v)
{
int aux,p=1;
v=0;
aux=x;
while(aux>0)
{
v=v*10+(aux%10);
aux=aux/10;
}
return v;
}


