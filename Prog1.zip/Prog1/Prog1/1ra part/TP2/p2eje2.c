#include<stdio.h>
int main (int argc, char *argv[])
{



int a,b,c,d,s,p;

printf("\n       \" TP2 ejercicio2\" ");

printf("\n Ingresar un numero:");
scanf("%d",&a);
printf("\n Ingresar un numero:");
scanf("%d",&b);
printf("\n Ingresar un numero:");
scanf("%d",&c);
printf("\n Ingresar un numero:");
scanf("%d",&d);
s=a+b+c+d;
p=s/4;
printf("\n la suma es:%d",s);
printf("\n el promedio es:%d",p);

return 0;
}
