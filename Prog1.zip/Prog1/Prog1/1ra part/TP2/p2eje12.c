// tp2- eje 12 - serie de fibonacci

#include <stdio.h>
int main (int argc, char *argv[])
{
int n,cont,i,fib;
printf("\n\n    \" n numeros de la serie de fibonacci\"   \n\n\n ");
do
{
printf("\n ingresar un numero:");
scanf("%d",&n);
}
while(n<0);
    cont=0;
    i=1;
    fib=0;
        while(cont<n)
        {
        printf("\n %d",fib);
        fib=i+cont;
        i++;
        cont++;
        }
 return 0;
}
