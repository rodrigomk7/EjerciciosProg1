#include<stdio.h>
int main(int argc, char *agrv[])
{
	float m,d,c;
	printf("\n Ingresar una media en metros:");
	scanf("%f",&m);
	d=m*10;
	c=m*100;
	printf("\n su convercion en decimetros es:%f dm",d);
	printf("\n su convercion en centimetro es:%f cm",c);
	return 0;
}