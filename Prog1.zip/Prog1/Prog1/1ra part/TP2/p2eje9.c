// tp2- eje 9 -

#include <stdio.h>
int main (int argc, char *argv[])
{
int n,cont,ban,x,may,men;
printf("\n\n    \" Programa Para Buscar El Mayor Y El Menor Valor Ingresado \"   \n\n\n ");
do
{
printf("\n ingresar un numero:");
scanf("%d",&n);
}
while(n<0);
        cont=0;
        ban=1;
        while(cont<n)
        {
        printf("\n Ingresar un numero del conjunto:");
        scanf("%d",&x);
                if(ban!=1)
                {
                if(x>may)
                        {
                        may=x;
                       // ban=7;
                        }
                        if(x<men)
                        {
                        men=x;
                        
                        }
                }
                else
                {
                may=x;
                men=x;
                ban=7;
                }
                cont++;
                }
        printf("\n el mayor numero ingresado es: %d",may);
        printf("\n el menor numero ingresado es: %d \n\n\n",men);
    return 0;
    }
                
