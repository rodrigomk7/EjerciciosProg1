#include<stdio.h>
int main( int argc, char *argv[])
{
	printf("\n       \" ...Programa Para Calcular El Factorial De Un Numero N... \" ");
	int n,f,i,x; 
	printf(" \n Ingresar Un Numero:");
	scanf("%d",&n);
	i=1; 
	x=1;
	f=1;
	     while (i<=n)
      	{
        		f=f*x; 
        		x++;
        		i++;
       	} 
	printf (" \n El Factorial De El Numero %d es: %d", n, f);
	return 0;
}
		