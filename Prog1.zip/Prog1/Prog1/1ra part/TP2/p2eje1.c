#include<stdio.h>
int main (int argc, char *argv[])
{
int n,d,c,r;
do
{
printf("\n ingresar el dividendo:");
scanf("%d",&n);
printf("\n ingresar el divisor:");
scanf("%d",&d);
}
while(n<=0||d<=0);
c=n/d;
r=n%d;
printf("\n el cociente es:%d",c);
printf("\n el resto es:%d",r);
return 0;
}
