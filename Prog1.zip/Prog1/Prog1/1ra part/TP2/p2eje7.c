#include<stdio.h>
int main( int argc, char *argv[])
{
	
int n, i, x;

printf("\n       \" Este Programa Muestra Los N Primeros Numeros Mayores Que 0... \" ");

printf ("\n Ingresar un valor N:");
scanf("%d",&n);
i=1; x=1;
while(i<=n)
    {
    	printf("\n %d",x);
    	x++;
    	i++;
    }
    return 0;
}
	       
