// tp2- eje 6 -

#include <stdio.h>
int main (int argc, char *argv[])
{
int dd,mm,aaaa,aux,dr,mr,ar;
printf("\n\n    \" PROG. PARA SABER LOS ANIOS, MESES Y DIAS QUE VIVIO HASTA EL 2016   \"   \n\n\n ");

do{
printf("\n ingresar dia de nacimiento:");
scanf("%d",&dd);}while(dd>31);
do{
printf("\n ingresar mes de nacimiento:");
scanf("%d",&mm);}while(mm>12);
do{
printf("\n ingresar anio de nacimiento:");
scanf("%d",&aaaa);}while(aaaa>2016);

ar=2016-aaaa;
aux=ar;

mr=aux*12;
dr=aux*365;

printf("\n su edad es:%d \n",ar);
printf("\n a vivido hasta el anio 2016 %d meses \n",mr);
printf("\n a vivio hasta el anio 2016 %d dias \n ",dr);
return 0;
}
