#include <stdio.h>
int main (int argc,char *argv[])
{
int a,b,c;

printf("\n Ingresar un lado del triangulo:");
scanf("%d",&a);
printf("\n Ingresar otro lado del triangulo:);
scanf("%d",&b);
printf("\n Ingresar el lado restante del triangulo:");
scanf("%d",&c);

if(a*a!=b*b+c*c)
        {
        if(b*b!=c*c+a*a)
            {
             if(c*c!=a*a+b*b)
              {
              printf(" los lados %d,%d,%d no son lados de un triangulo rectangulo",a,b,c);
              }
              else
              {
              printf("\n los lados %d,%d,%d son lados de un triangulo rectangulo",a,b,c);
              }
           }
           else
              {
              printf("\n los lados %d,%d,%d son lados de un triangulo rectangulo",a,b,c);
              }
        }
              else
              {
            printf("\n los lados %d,%d,%d son lados de un triangulo rectangulo" ,a,b,c);
              }
          return 0;
}    
