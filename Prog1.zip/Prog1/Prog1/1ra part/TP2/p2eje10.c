/* p2 eje10 - sumar numeros enteros comprendidos
 entre dos numeros enteros ingresados */

#include <stdio.h>
int main (int argc, char *argv[])
{
  int a,b,ca,s,aux;


do
{
printf("\n ingresar un numero:");
scanf("%d",&a);
printf("\n ingresar otro numero:");
scanf("%d",&b);

printf("\n\n");
}while(a>b);

ca=a+1;
s=0;
aux=a+1;

while(ca<b)
      {
             if(ca==b-1)
                 {
                 printf(" %d ",ca);
                 }
              else
                 {
                 printf(" %d + ",ca);
                 }
      s=s+aux;
      aux=aux+1;
      ca++;
      }
        printf(" = %d",s);
        printf("\n\n");
 return 0;
}
