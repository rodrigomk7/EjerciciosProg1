#include<stdio.h>
int main ()
{
int x=10,y=100%90,i;
for(i=1;x<10;i++)

  if(x!=y);

      printf("x=%d  y=%d",x,y);
      
return 0;
}