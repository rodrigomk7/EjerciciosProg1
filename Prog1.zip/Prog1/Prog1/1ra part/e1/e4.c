#include<stdio.h>

int f_4(int x, int y, int *m);

int main (int argc,char *argv[])
{
int z=0,k=3,m=5,r=0;

printf(" %d %d %d %d \n",k,m,r,z);

z=f_4(k,m,&r);
printf(" %d %d %d %d \n",k,m,r,z);

z=f_4(m,k,&r);
printf(" %d %d %d %d \n",k,m,r,z);

return 0;
}

int f_4(int x, int y, int *m)
{
int static f4=9;
int z=0;
x=x+2;
y=y+3;
z=z+y+1+*m;
f4=f4 +x;
*m=f4;
printf(" %d %d %d %d %d \n ",x,y,f4,z,*m);
return (x+y);
} 
