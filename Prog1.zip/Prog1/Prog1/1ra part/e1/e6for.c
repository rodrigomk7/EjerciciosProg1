#include<stdio.h>
int main (int argc,char *argv[])
{
int x=1;
int y;
for(;x<=10;x+=3)
{
y=x*x;
printf("\n %d",x);
}
return 0;
}
