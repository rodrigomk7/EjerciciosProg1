#include<stdio.h>

int f_5();

int main (int argc,char *argv[])
{
int j=0;
        for(;j<4;)
        printf(" %d %d \n", j++, f_5());
    return 0;
    }

 int f_5()
 {
 int j=0;

 if(!j)
 return j++;
 else
 return j--;
 }
 
