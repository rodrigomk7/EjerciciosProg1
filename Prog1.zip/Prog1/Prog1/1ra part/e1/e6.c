#include<stdio.h>
int main (int argc,char *argv[])
{
int x=1;
int y;
while(x<=10)
{
y=x*x;
printf("\n %d",x);
x +=3 ;
}
return 0;
}
