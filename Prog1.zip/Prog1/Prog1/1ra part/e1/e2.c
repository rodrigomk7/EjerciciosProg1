#include<stdio.h>
int main (int argc,char *argv[])
{
float x=11.11;
int *p;
p=&x;
*p=x+22.22;
printf(" %f ",x);
return 0;
}
