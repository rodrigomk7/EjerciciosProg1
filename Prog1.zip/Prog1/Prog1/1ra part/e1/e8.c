#include<stdio.h>
int main (int argc,char *argv[])
{
int x=2;
if(!x+3)

    printf("Hola mundo! %d",x);
   else
    printf(" Bienvenidos! %d",x);

return 0;
}
