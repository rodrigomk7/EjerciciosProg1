#include<stdio.h>
int main (int argc,char *argv[])
{
int x=0;
swith (x);
{

 case 0:
        printf("\n x vale 0");
 case 1:
        printf("\n x vale 1");
 case 2:
        printf("\n x vale 2");
        break;
 case 3:
        printf("\n x vale 3");
        break;

      

        
 }
 return 0;
 }
