#include<stdio.h>
int main (int argc,char *argv[])
{
int x=10, y=15, z=20;

printf("\n\n %d",!(x<10));
printf("\n\n %d", x<=5 || y>15);
printf("\n\n %d",(x!=5)&&(y==z));
printf("\n\n %d", x<=z && (x+y>=z));
return 0;
}
