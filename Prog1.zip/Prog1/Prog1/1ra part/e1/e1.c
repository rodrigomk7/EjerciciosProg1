#include<stdio.h>

int f_1();

int main (int argc,char *argv[])
{
int j=0;
for(;j<4;)

        printf(" %d %d \n ",j++,f_1());
   return 0;
}

int f_1()
{
 static int j;

 if(!j)
        return j--;
     else
        return j++;
}
