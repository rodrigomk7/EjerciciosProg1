#include<stdio.h>
int main (int argc,char *argv[])
{
int x=20, y=35;
x= y++ + x++;
y=++y + ++x;
printf(" %d %d \n",x,y);

return 0;
}
