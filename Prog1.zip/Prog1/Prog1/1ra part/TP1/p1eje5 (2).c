#include<stdio.h>
int main (int argc, char *argv[])
{
	int n=1000;
	printf("\n %d",n);
	while(n<9999)
	{
	n++;
	printf("\n %d", n);
	}
	return 0;
}