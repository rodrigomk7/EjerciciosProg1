#include<stdio.h>
int main (int argc,char *argv [])
{
int x,y,z;
printf("\n Ingresar un numero:");
scanf("%d",&x);
printf("\n Ingresar otro un numero:");
scanf("%d",&y);
printf("\n Ingresar nuevamente otro un numero:");
scanf("%d",&z);
if(x<y||y<z)
        {
        if(y<z||z<x)
                {
                if(z<x||x<y)
                        {
                        printf("son iguales");
                        }
                        else
                        {
                        printf("el orden:%d",&z,&y,&x);
                        }
               }
               else
               {
               printf("el orden:%d",&y,&z,&x);
               }
        }
        else
        {
        printf("el orden:%d",&x,&y,&z);
        }
 return 0;
 }
