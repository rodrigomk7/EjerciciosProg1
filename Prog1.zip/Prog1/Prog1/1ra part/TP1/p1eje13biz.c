#include<stdio.h>
int main (int argc,char *argv [])
{
int n,x,y,cont=1,may,men,pmay,pmen;
printf("\n Ingresar una cantidad de numeros enteros:");
scanf("%d",&n);
printf("\n Ingresar el primer numero:");
scanf("%d",&x);
may=x;
men=x;
cont++;
while(cont<=n)
        {
        printf("\n Ingresar el siguiente numero:");
        scanf("%d",&y);
                if(y>may)
                {
                may=y;
                pmay=cont;
                }
                else
                {
                  if(y<men)
                  {
                  men=y;
                  pmen=cont;
                  }
                }
                cont++;
                }
        printf("\n el mayor numero ingresado es:%d",may);
        printf("\n la posicion en la ingreso el mayor es:%d",pmay);
        printf("\n el menor numero ingresado es:%d",men);
        printf("\n la posicion en la ingreso el menor es:%d",pmen);

        return 0;
   }

        
