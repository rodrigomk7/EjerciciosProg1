/* tp1 eje 8 control binario */

#include <stdio.h>
int main (int argc, char *argv[])
{
int n,aux,c; 
do
{
printf("ingresar un numero:");
scanf("%d",&n);
}while(n<0);
aux=n;
c=0;
        while(aux!=0)
        {
        if(aux%10>2)
        {
        c=c+1;
        }
        aux=aux/10;
        }

        if(c==0)
        {
        printf("\n ES BINARIO");
        }
        else
        {
        printf("\n NO ES BINARIO");
        }
return 0;
}
