//P1-eje17- encontrar el menor impar y dar su posicion

#include<stdio.h>
int main (int argc, char *argv[])
{
int n,x,cont=1,ban=1,men,pm,i=1;

do
{ 
printf("\n Ingresar la cantidad del conjunto de numeros:");
scanf("%d",&n);
}while(n<0);
	while(cont<=n)
	{
	printf("\n Ingresar un valor del conjunto:" );
	scanf("%d",&x);
           if(x%2!=0)
		{
			if(ban!=1)
			{
			     if(x<men)
				{
				men=x;
				pm=cont;
				}
			}
			else
			{
			men=x;
			pm=cont;
			ban=7;
			}
                  }
		  else
		  {
		  i++;
                  }
         cont++;
         }
if(cont!=i)
	{
	printf("\n El menor numero impar ingrasado es:%d  \n",men);
	printf("\n La posicion en la que ingreso fue:%d ",pm);
	}
	else
	{
	printf("\n \"No se ingresaron valores impares\" \n\n\n");
	}

return 0;
}
