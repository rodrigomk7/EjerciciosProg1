/* tp n°1- eje 12- ingresar n numeros y 
calcular el promedio de los pares y de los impares, si no se 
ingresaron valores pares ni impares mostrar un mensaje*/
#include <stdio.h> 
int main(int argc, char *argv[])
{
int n,x,cont=1,sp=0,si=0,cp=0,ci=0,pp,pi,ban=0;
printf("\n Ingresar una cantidad de numeros:");
scanf("%d",&n);
while(cont<=n)
    {
        printf("\n Ingresar un numero:");
        scanf("%d",&x);
        if(x!=0)
        {
                if(x%2==0)
                {
                  cp++;
                  sp=sp+x;
                }
                else
                {
                ci++;
                si=si+x;
                }
        }
        else
        {
        ban++;
        }
        cont++;
    }
    if(ban==n)
    {
    printf("\n NO SE INGRESARON VALORES PARES, NI VALORES IMPARES");
    }
    else
    {
    pp=sp/cp;
    pi=si/ci;
    printf("\n el promedio de pares es:%d",pp);
    printf("\n el promedio de impares es:%d",pi);
    }
return 0;
}
    

