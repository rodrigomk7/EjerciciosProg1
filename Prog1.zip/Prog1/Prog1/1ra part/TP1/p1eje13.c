/* tp n°1 - eje 13- Se ingresan n numeros. Determinar el mayor valor 
ingresado y su posicion*/
#include<stdio.h>
int main (int argc,char *argv [])
{
int n,x,y,cont=1,may,pmay;
   printf("\n Ingresar una cantidad de numeros enteros:");
   scanf("%d",&n);
   printf("\n Ingresar el primer numero:");
   scanf("%d",&x);
   may=x;
   cont++;
while(cont<=n)
        {
        printf("\n Ingresar el siguiente numero:");
        scanf("%d",&y);
                if(y>may)
                {
                may=y;
                pmay=cont;
                }
                cont++;
                }
        printf("\n\n el mayor numero ingresado es:%d",may);
        printf("\n la posicion en la ingreso el mayor numero es:%d",pmay);
        
        return 0;
   }

        
