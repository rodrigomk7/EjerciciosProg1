#include <stdio.h>
int main (int argc, char *argv[])
{
int n=100,d,cont;
while(n<=1000)
    {
      cont=0;
      d=2;
	while(n>d)
	{
		if(n%d==0)
		{
		cont++;
		}
          d++;
	}
            if(cont==0)
		{
		printf("\n %d",n);
		}
	    n++;
    }
return 0;
}
