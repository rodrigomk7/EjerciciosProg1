#include <stdio.h>
int main (int argc, char*argv[])
{
int a;
int mod;

print("\n Ingrese un a�o:");
scanf("%d",&a);

if(a mod 400!==0)
  {
	if(a mod 4==0 and a mod 100!=0)
		{
		pritf("el a�o es bisiesto");
		}
		else
		{
		pritf("el a�o NO es bisiesto");
		}
  }
  else
  {
   pritf("el a�o es bisiesto");
  }
return 0;
}