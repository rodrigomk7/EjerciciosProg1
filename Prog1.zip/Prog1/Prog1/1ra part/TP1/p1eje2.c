#include <stdio.h>
int main (int argc, char*argv[])
{
int n;
printf("\n ingresar un numero del 1 al 7:");
scanf("%d",&n);
if(n!=1)
{
if(n!=2)
{
if(n!=3)
{
if(n!=4)
{
if(n!=5)
{
if(n!=6)
{
if(n!=7)
{
printf("\n VALOR INCORRECTO");
}
else
{
printf("\n El dia es DOMINGO");
}
}
else
{
printf("\n El dia es SABADO");
}
}
else
{
printf("\n El dia es VIERNES");
}
}
else
{
printf("\n El dia es JUEVES");
}
}
else
{
printf("\n El dia es MIERCOLES");
}
}
else
{
printf("\n El dia es MARTES");
}
}
else					
{
printf("\n El dia es LUNES");					
}
return 0;
}