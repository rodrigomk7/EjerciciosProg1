//P1-eje16- simplificar una fraccion

#include<stdio.h>
int main (int argc, char *argv[])
{



int a,b,d,f,div=1,cd=1;
printf(" \n\n \" ... PROGRAMA PARA SIMPLIFICAR FRACCIONES ... \" ");

do
{
printf("\n\n Ingresar el numerador de la fraccion:");
scanf("%d",&a);
printf(" \n\n Ingresar el denominador de la fraccion:");
scanf("%d",&b);
}while(a<0||b<0);

        while(a>=div && b>=div)
        {
        if(a%div==0)
                {
                if(b%div==0)
                        {
                        cd=div;
			a=a/cd;
			b=b/cd;
                        }
                }
        div++;
        }
        
        
        printf("\n\n La fraccion simplificada es:  %d/%d \n\n\n\n",a,b);

 return 0;
 }