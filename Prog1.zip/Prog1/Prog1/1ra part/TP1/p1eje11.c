/* tp n°1 - ejercicio 11 - divicion entera(usando restas)*/
#include <stdio.h> 
int main(int argc, char *argv[])
{
int n,d,ban,r,c;
do 
{
printf("Ingresar un numero:");
scanf("%d",&n);
printf("Ingresar otro numero:");
scanf("%d",&d);
}while((n<0)||(d<0));
r=n;
c=0;
        while(r>=d)
        {
        r=r-d;
        c=c+1;
        ban=7;
        }

        if(ban==7)
        {
       printf("\n el cociente es:%d",c);
       printf("\n y el resto es:%d",r);
        }
        else
        {
         printf("\n no se puede realizar la divicion entera");
         }
 return 0;
}
        
