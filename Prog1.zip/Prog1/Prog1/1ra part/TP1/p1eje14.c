/* tp n°1 - eje 14- */
#include<stdio.h>
int main (int argc,char *argv [])
{
int  n,x,r,cont=1,ban=0,ci=0,aux;
  do
   {
   printf("\n Ingresar una cantidad de numeros enteros:");
   scanf("%d",&n);
   }while(n<0);
     while(cont<=n)
        {
          printf("\n Ingresar un numero:");
          scanf("%d",&x);
          aux=x;
           while(aux>0)
               {
                r=aux%10;
                 aux=aux/10;
                if(r%2!=0)
                     {
                      ban=1;
                     }
               }
                if(ban==1)
                   {
                    ci++;
                   }
        cont++;
        }
        printf("\n La cantidad de numeros que poseen al menos un digito impar es %d",ci);
     return 0;
     }
