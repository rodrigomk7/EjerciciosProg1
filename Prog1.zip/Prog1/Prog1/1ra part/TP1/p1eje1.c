/* tp1 eje 1 */

#include <stdio.h>
int main (int argc, char*argv[])
{
float x,d,p,a;
float pi=3.14;
printf("\n ingresar el valor de radio del circulo:");
scanf("%f",&x);
d=x+x;
p=2*pi*x;
a=pi*x*x;
printf("\n El valor del diametro es:%.2f",d);
printf("\n El valor del perimetro es:%.2f",p);
printf("\n El valor del area es:%.2f",a);
return 0;
}
