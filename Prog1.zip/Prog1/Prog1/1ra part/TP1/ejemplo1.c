#include <stdio.h>
int main (int argc, char*argv[])
{
float x,y,s,p;

printf("ingrese un numero real:");
scanf("%f",&x);
printf("ingrese otro numero real:");
scanf("%f",&y);
s=x+y;
p=x*y;
printf("\n La suma es:%2f",s);
printf("\n El prodructo es:%2.f",p);

return 0;
}