/* 
	Universidad Nacional de Tucum�n
	Facultad de Ciencias Exactas y Tecnolog�a
	Departamento de Electricidad, Electr�nica y Computaci�n
	A�o 2016
	
	Programaci�n I
	Ingenier�as: El�ctrica, Electr�nica y en Computaci�n
	Profesor: Ing. Jorge Steifensand
	
	Unidad 2
	
	Ejemplo 5
	Funciones definidas por el usuario:
		* No recibe par�metros
		* No devuelve  valor
*/

#include <stdio.h> 

 
void mensaje();

int main(int argc, char *argv[])
{
	mensaje();
		
printf("\n\n");	
return 0;
}

void mensaje()
{
	system("cls"); 
	printf("\n\n\n\n\n\n");
	printf("\t\t\t PROGRAMACION I");
	printf("\n\t\t\t ============ =");
	printf("\n\n\n\n\n\n");
	printf("\t\t\t      2016");
	printf("\n\t\t\t      ====");
		
printf("\n\n\n\n\n\n");
return;
}
